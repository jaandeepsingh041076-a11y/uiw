local fn = _gn(0x2f731ae7)
--- Set volumetric light properties for an existing light, enabling custom volumetric effects such as fog-like glow.
-- @param volIntensity Intensity of the volumetric effect
-- @param volSizeScale Scale of the volumetric volume
-- @param r Red channel for volumetric outer color (0–255)
-- @param g Green channel for volumetric outer color (0–255)
-- @param b Blue channel for volumetric outer color (0–255)
-- @param i Intensity (alpha) of the volumetric outer color
-- @param outerExponent Exponent controlling falloff of the volumetric outer glow
function Global.SetLightVolumeDetails(volIntensity, volSizeScale, r, g, b, i, outerExponent)
	return fn(volIntensity, volSizeScale, r, g, b, i, outerExponent)
end

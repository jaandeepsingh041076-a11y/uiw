local fn = _gn(0x202A5ED9CE01D6E7)
--- Attaches a camera to an entity, including full matrix transformations for both rotation and position offsets.
-- ```
-- NativeDB Introduced: v2189
-- ```
-- @param cam The camera handle.
-- @param entity The entity handle.
-- @param xRot X-axis rotation.
-- @param yRot Y-axis rotation.
-- @param zRot Z-axis rotation.
-- @param xOffset X-axis offset
-- @param yOffset Y-axis offset
-- @param zOffset Z-axis offset
-- @param isRelative Whether or not the camera position will be relative to the entity rotation
function Global.HardAttachCamToEntity(cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
	return fn(cam, entity, xRot, yRot, zRot, xOffset, yOffset, zOffset, isRelative)
end

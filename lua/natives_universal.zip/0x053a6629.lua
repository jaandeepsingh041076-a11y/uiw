local fn = _gn(0x04701832B739DCE5)
--- TASK_GO_TO_ENTITY_WHILE_AIMING_AT_COORD
function Global.TaskGoToEntityWhileAimingAtCoord(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
	return fn(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
end

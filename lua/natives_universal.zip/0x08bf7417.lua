local fn = _gn(0x710311ADF0E20730)
--- ACTIVATE_PHYSICS
function Global.ActivatePhysics(entity)
	return fn(entity)
end

local fn = _gn(0x7CAEC29ECB5DFEBB)
--- REGISTER_FLOAT_TO_SAVE
function Global.RegisterFloatToSave(name)
	return fn(_i, _ts(name))
end

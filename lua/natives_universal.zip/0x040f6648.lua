local fn = _gn(0x34D66BC058019CE0)
--- GET_CURRENT_TRACK_SOUND_NAME
-- @return The current sound name as a hash for the currently playing track on the given station.
function Global.N_0x34d66bc058019ce0(radioStationName)
	return fn(_ts(radioStationName), _ri)
end

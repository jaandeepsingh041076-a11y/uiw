local fn = _gn(0x7A1ADEEF01740A24)
--- NETWORK_GET_DESTROYER_OF_NETWORK_ID
function Global.NetworkGetDestroyerOfNetworkId(netId, weaponHash)
	return fn(netId, _ii(weaponHash) --[[ may be optional ]], _ri)
end

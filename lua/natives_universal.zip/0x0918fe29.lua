local fn = _gn(0x957E790EA1727B64)
--- _CLEAR_CLOUD_HAT
function Global.ClearCloudHat()
	return fn()
end

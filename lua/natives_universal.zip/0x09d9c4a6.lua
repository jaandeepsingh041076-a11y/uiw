local fn = _gn(0x6C8065A3B780185B)
--- Sets the specified ped to use a specific voice different to the one associated with their model.
function Global.SetAmbientVoiceName(ped, voiceName)
	return fn(ped, _ts(voiceName))
end

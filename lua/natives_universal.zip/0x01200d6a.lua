local fn = _gn(0xfbdb885f)
--- Gets local index inside a collection (which can be obtained using [GET_PED_COLLECTION_NAME_FROM_PROP](#\_0x8ED0C17)) for the given global prop index. The collection name and index are used in functions like [SET_PED_COLLECTION_PROP_INDEX](#\_0x75240BCB).
-- @param ped The target ped
-- @param anchorPoint One of the anchor points from [SET_PED_PROP_INDEX](#\_0x93376B65A266EB5F)
-- @param propIndex Global prop index. Same as set by `drawableId` in [SET_PED_PROP_INDEX](#\_0x93376B65A266EB5F). Global prop index points to prop as if props from all collections for the given component are placed into one continuous array.
-- @return Local index inside a collection that the given global prop index corresponds to. Returns -1 if Ped is not found or the global index is out of bounds.
function Global.GetPedCollectionLocalIndexFromProp(ped, anchorPoint, propIndex)
	return fn(ped, anchorPoint, propIndex, _ri)
end

local fn = _gn(0x43A66C31C68491C0)
--- Gets the ped for a specified player index.
-- Note: For performance reasons, usage of [`PLAYER_PED_ID`](#\_0xD80958FC74E988A6) is recommended over the use of `GetPlayerPed(-1)` when wanting to acquire your local player ped. For more information, please refer to [this](https://forum.cfx.re/t/question-difference-between-getplayerped-1-and-playerpedid/539437/2) forum post.
-- @param playerId The player index, or -1 to get the local player ped.
-- @return The specified player's ped, or 0 if invalid.
function Global.GetPlayerPed(playerId)
	return fn(playerId, _ri)
end

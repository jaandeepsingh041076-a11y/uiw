local fn = _gn(0xDBA3C090E3D74690)
--- REQUEST_VEHICLE_*
function Global.N_0xdba3c090e3d74690(vehicle)
	return fn(vehicle)
end

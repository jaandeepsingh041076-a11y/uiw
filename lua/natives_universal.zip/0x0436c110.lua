local fn = _gn(0x0DB57B41EC1DB083)
--- GET_WEAPON_COMPONENT_TYPE_MODEL
function Global.GetWeaponComponentTypeModel(componentHash)
	return fn(_ch(componentHash), _ri)
end

local fn = _gn(0x4BC2854478F3A749)
--- DOOR_SYSTEM_GET_DOOR_PENDING_STATE
function Global.DoorSystemGetDoorPendingState(doorHash)
	return fn(_ch(doorHash), _ri)
end

local fn = _gn(0x5D517B27CF6ECD04)
--- RELEASE_PEDHEADSHOT_IMG_UPLOAD
function Global.N_0x5d517b27cf6ecd04(id)
	return fn(id)
end

local fn = _gn(0xF1AE5DCDBFCA2721)
--- _LEADERBOARDS2_READ_BY_PLATFORM
function Global.N_0xf1ae5dcdbfca2721(gamerHandleCsv, platformName)
	return fn(_i, _ts(gamerHandleCsv), _ts(platformName), _r)
end

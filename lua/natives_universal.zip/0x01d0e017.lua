local fn = _gn(0x28157D43CF600981)
--- SET_SCENARIO_PEDS_SPAWN_IN_SPHERE_AREA
function Global.SetScenarioPedsSpawnInSphereArea(x, y, z, range, p4)
	return fn(x, y, z, range, p4)
end

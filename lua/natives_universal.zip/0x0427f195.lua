local fn = _gn(0x4E5C93BD0C32FBF8)
--- RESERVE_NETWORK_MISSION_OBJECTS
function Global.ReserveNetworkMissionObjects(amount)
	return fn(amount)
end

local fn = _gn(0x617F49C2668E6155)
--- NETWORK_GET_NUM_*
function Global.N_0x617f49c2668e6155()
	return fn(_ri)
end

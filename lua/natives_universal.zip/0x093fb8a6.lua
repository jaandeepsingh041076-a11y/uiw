local fn = _gn(0xD68A5FF8A3A89874)
--- Sets the color of HUD_COLOUR_SCRIPT_VARIABLE
function Global.N_0xd68a5ff8a3a89874(r, g, b, a)
	return fn(r, g, b, a)
end

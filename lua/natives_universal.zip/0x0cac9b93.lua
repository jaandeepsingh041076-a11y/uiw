local fn = _gn(0x480142959D337D00)
--- Drive randomly with no destination set.
-- @param ped Ped id for the task.
-- @param vehicle Vehicle entity id for the task.
-- @param speed Speed of driving.
-- @param drivingStyle The driving style (default is 0) (see [SetDriveTaskDrivingStyle](#\_0xDACE1BE37D88AF67)).
function Global.TaskVehicleDriveWander(ped, vehicle, speed, drivingStyle)
	return fn(ped, vehicle, speed, drivingStyle)
end

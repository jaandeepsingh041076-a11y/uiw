local fn = _gn(0x7C6B0C22F9F40BBE)
--- DOES_GROUP_EXIST
function Global.DoesGroupExist(groupId)
	return fn(groupId, _r)
end

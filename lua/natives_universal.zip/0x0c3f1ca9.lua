local fn = _gn(0xF3BBE884A14BB413)
--- Refer to [`SET_WEATHER_TYPE_NOW`](#\_0x29B487C359E19889) for weather types.
function Global.GetWeatherTypeTransition()
	return fn(_i, _i, _f)
end

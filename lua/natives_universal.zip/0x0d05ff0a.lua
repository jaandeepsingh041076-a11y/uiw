local fn = _gn(0x855BC38818F6F684)
--- NETWORK_SESSION_IS_IN_VOICE_SESSION
function Global.N_0x855bc38818f6f684()
	return fn(_r)
end

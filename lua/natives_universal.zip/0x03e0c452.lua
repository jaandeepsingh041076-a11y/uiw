local fn = _gn(0x7C0A893088881D57)
--- HAS_CUTSCENE_FINISHED
function Global.HasCutsceneFinished()
	return fn(_r)
end

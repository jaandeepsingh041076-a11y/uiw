local fn = _gn(0x07E5B515DB0636FC)
--- Renders the camera previously created with [CREATE_CAM](#\_0xC3981DCE61D9E13F) or [CREATE_CAMERA](#\_0x5E3CF89C6BCCA67D)
-- ```
-- NativeDB Added Parameter 6: Any p5
-- ```
-- @param render Whether to render the cams or not.
-- @param ease If true it will make a smooth transition between the current camera and the new rendered camera.
-- @param easeTime The in milliseconds for the transition to happen.
-- @param easeCoordsAnim If false it will only do the smooth transition to the rotation and the coords will be set instantly.
-- @param p4 Doesn't seem to change anything.
function Global.RenderScriptCams(render, ease, easeTime, easeCoordsAnim, p4)
	return fn(render, ease, easeTime, easeCoordsAnim, p4)
end

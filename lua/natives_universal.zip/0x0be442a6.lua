local fn = _gn(0x6D6840CEE8845831)
--- Possible values:
-- act_cinema
-- am_mp_carwash_launch
-- am_mp_carwash_control
-- am_mp_property_ext
-- chop
-- fairgroundHub
-- launcher_BasejumpHeli
-- launcher_BasejumpPack
-- launcher_CarWash
-- launcher_golf
-- launcher_Hunting_Ambient
-- launcher_MrsPhilips
-- launcher_OffroadRacing
-- launcher_pilotschool
-- launcher_Racing
-- launcher_rampage
-- launcher_rampage
-- launcher_range
-- launcher_stunts
-- launcher_stunts
-- launcher_tennis
-- launcher_Tonya
-- launcher_Triathlon
-- launcher_Yoga
-- ob_mp_bed_low
-- ob_mp_bed_med
function Global.N_0x6d6840cee8845831(action)
	return fn(_ts(action))
end

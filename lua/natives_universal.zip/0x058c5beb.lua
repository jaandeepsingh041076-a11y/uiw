local fn = _gn(0x2CE544C68FB812A0)
--- ADD_ROAD_NODE_SPEED_ZONE
function Global.AddRoadNodeSpeedZone(x, y, z, radius, speed, p5)
	return fn(x, y, z, radius, speed, p5, _ri)
end

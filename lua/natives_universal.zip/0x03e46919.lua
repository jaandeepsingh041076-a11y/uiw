local fn = _gn(0x761B77454205A61D)
--- p1 was always -1
function Global.AddTextComponentAppTitle(p0, p1)
	return fn(_ts(p0), p1)
end

local fn = _gn(0x9CD43EEE12BF4DD0)
--- Example:
-- GRAPHICS::ADD_ENTITY_ICON(a_0, "MP_Arrow");
-- I tried this and nothing happened...
function Global.AddEntityIcon(entity, icon)
	return fn(entity, _ts(icon), _ri)
end

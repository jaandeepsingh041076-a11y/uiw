local fn = _gn(0x957838AAF91BD12D)
--- MISC::_0x957838AAF91BD12D(x, y, z, radius, false, false, false, false); seem to make all objects go away, peds, vehicles etc. All booleans set to true doesn't seem to change anything.
function Global.ClearAreaOfEverything(x, y, z, radius, p4, p5, p6, p7)
	return fn(x, y, z, radius, p4, p5, p6, p7)
end

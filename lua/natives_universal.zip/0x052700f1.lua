local fn = _gn(0xD705740BB0A1CF4C)
--- HAS_PLAYER_BEEN_SPOTTED_IN_STOLEN_VEHICLE
function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return fn(player, _r)
end

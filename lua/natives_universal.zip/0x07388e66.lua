local fn = _gn(0x023ACAB2DC9DC4A4)
--- NativeDB Introduced: v1493
function Global.N_0x023acab2dc9dc4a4()
	return fn(_ri)
end

local fn = _gn(0xA306F470D1660581)
--- 0xA306F470D1660581
function Global.N_0xa306f470d1660581()
	return fn(_ri)
end

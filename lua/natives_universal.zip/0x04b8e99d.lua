local fn = _gn(0x1612C45F9E3E0D44)
--- 0x1612C45F9E3E0D44
function Global.N_0x1612c45f9e3e0d44()
	return fn()
end

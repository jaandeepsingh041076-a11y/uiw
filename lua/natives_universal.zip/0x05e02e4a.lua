local fn = _gn(0xB51B9AB9EF81868C)
--- 0xB51B9AB9EF81868C
function Global.N_0xb51b9ab9ef81868c(toggle)
	return fn(toggle)
end

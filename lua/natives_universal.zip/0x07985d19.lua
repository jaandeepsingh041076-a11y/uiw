local fn = _gn(0x6EF54AB721DC6242)
--- _REMOVE_WARNING_MESSAGE_LIST_ITEMS
function Global.N_0x6ef54ab721dc6242()
	return fn()
end

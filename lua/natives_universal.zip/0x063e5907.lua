local fn = _gn(0x84D7FFD223CAAFFD)
--- NativeDB Introduced: v3407
-- @return Does not actually return anything.
function Global.SetVehicleExplosiveDamageScale(vehicle, scale)
	return fn(vehicle, scale, _ri)
end

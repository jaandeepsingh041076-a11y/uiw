local fn = _gn(0x341DE7ED1D2A1BFD)
--- DOES_SHOP_PED_APPAREL_HAVE_RESTRICTION_TAG
function Global.DoesShopPedApparelHaveRestrictionTag(componentHash, restrictionTagHash, componentId)
	return fn(_ch(componentHash), _ch(restrictionTagHash), componentId, _r)
end

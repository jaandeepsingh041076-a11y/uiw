local fn = _gn(0xB165AB7C248B2DC1)
--- UNLOCK_MISSION_NEWS_STORY
function Global.UnlockMissionNewsStory(newsStory)
	return fn(newsStory)
end

local fn = _gn(0x593850C16A36B692)
--- Starts a new singleplayer game (at the prologue).
function Global.ShutdownAndLaunchSinglePlayerGame()
	return fn()
end

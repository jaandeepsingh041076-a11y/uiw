local fn = _gn(0x38D5B0FEBB086F75)
--- NETWORK_GET_PRESENCE_INVITE_HANDLE
function Global.NetworkGetPresenceInviteHandle(p0, p1)
	return fn(p0, _ii(p1) --[[ may be optional ]], _r)
end

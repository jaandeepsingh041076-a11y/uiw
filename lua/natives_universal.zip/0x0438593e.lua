local fn = _gn(0x41B9FB92EDED32A6)
--- Changes the key used to transform a vehicle into submarine mode. When set to true, the transformation key switches from the default raise/lower convertible roof key (usually 'H') to the special vehicle transformation key (usually 'X').
-- ```
-- NativeDB Introduced: v1365
-- ```
-- @param vehicle The vehicle for which the submarine mode should be configured.
-- @param useAlternateInput A boolean switch to enable/disable the use of alternate input.
function Global.SetTransformToSubmarineUsesAlternateInput(vehicle, useAlternateInput)
	return fn(vehicle, useAlternateInput)
end

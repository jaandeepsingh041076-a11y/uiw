local fn = _gn(0xDC6F8601FAF2E893)
--- SET_*
-- Only called within 1 script for x360. 'fm_mission_controller' and it used on an object.
-- Ran after these 2 natives,
-- set_object_targettable(uParam0, 0);
-- set_entity_invincible(uParam0, 1);
function Global.SetWaitForCollisionsBeforeProbe(entity, toggle)
	return fn(entity, toggle)
end

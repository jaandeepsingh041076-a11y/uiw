local fn = _gn(0x17DF68D720AA77F8)
--- GET_TENNIS_SWING_ANIM_COMPLETE
function Global.GetTennisSwingAnimComplete(ped)
	return fn(ped, _r)
end

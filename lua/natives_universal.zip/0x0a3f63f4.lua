local fn = _gn(0x3C606747B23E497B)
--- Define the scope within which the ped will engage in combat with the target.
-- ```cpp
-- enum eCombatRange {
-- CR_NEAR = 0, // keeps within 5-15m
-- CR_MEDIUM = 1, // keeps within 7-30m
-- CR_FAR = 2, // keeps within 15-40m
-- CR_VERY_FAR = 3 // keeps within 22-45m
-- };
-- ```
-- @param ped Ped index
-- @param range See `eCombatRange` enum.
function Global.SetPedCombatRange(ped, range)
	return fn(ped, range)
end

local fn = _gn(0xE902EF951DCE178F)
--- GET_PLAYER_RGB_COLOUR
function Global.GetPlayerRgbColour(player)
	return fn(player, _i, _i, _i)
end

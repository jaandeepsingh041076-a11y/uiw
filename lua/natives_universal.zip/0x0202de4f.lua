local fn = _gn(0xDAF80797FC534BEC)
--- 0xDAF80797FC534BEC
function Global.N_0xdaf80797fc534bec(p0)
	return fn(p0)
end

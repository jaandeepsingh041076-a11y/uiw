local fn = _gn(0x90532EDF0D2BDD86)
--- DETACH_VEHICLE_FROM_TRAILER
function Global.DetachVehicleFromTrailer(vehicle)
	return fn(vehicle)
end

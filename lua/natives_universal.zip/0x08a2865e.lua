local fn = _gn(0x813A0A7C9D2E831F)
--- IS_PED_HEADTRACKING_ENTITY
function Global.IsPedHeadtrackingEntity(ped, entity)
	return fn(ped, entity, _r)
end

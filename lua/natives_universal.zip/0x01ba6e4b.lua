local fn = _gn(0xe97633cb)
--- Sets default writhe from bullet threshold value for specific health config.
-- @param configName Name of health config.
-- @param newValue Value
function Global.SetHealthConfigWritheFromBulletThreshold(configName, newValue)
	return fn(_ts(configName), newValue)
end

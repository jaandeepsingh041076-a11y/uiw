local fn = _gn(0x5F43D83FD6738741)
--- IS_PLAYER_VEH_RADIO_ENABLE
function Global.N_0x5f43d83fd6738741()
	return fn(_r)
end

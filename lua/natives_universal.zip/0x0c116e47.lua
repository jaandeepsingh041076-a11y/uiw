local fn = _gn(0x2A69FFD1B42BFF9E)
--- Transforms the `stormberg` to its "road vehicle" variant. If the vehicle is already in that state then the vehicle transformation audio will still play, but the vehicle won't change at all.
-- @param vehicle A vehicle handle.
-- @param instantly If true, the vehicle will be instantly transformed, when false the transform animation plays normally.
function Global.N_0x2a69ffd1b42bff9e(vehicle, instantly)
	return fn(vehicle, instantly)
end

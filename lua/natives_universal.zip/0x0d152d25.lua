local fn = _gn(0x20510814175EA477)
--- RESET_PED_STRAFE_CLIPSET
function Global.ResetPedStrafeClipset(ped)
	return fn(ped)
end

local fn = _gn(0xF113E3AA9BC54613)
--- Only 1 match. Both p1 & p2 were true.
-- ```
-- ```
-- NativeDB Added Parameter 4: Any p3
function Global.SpecialAbilityChargeMedium(player, p1, p2)
	return fn(player, p1, p2)
end

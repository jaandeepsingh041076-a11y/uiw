local fn = _gn(0xA071E0ED98F91286)
--- PLAYSTATS_ACTIVITY_DONE
function Global.N_0xa071e0ed98f91286(p0, p1)
	return fn(p0, p1)
end

local fn = _gn(0xEB1774DF12BB9F12)
--- STOP_SAVE_STRUCT
function Global.StopSaveStruct()
	return fn()
end

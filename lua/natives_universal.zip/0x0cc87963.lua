local fn = _gn(0xF28DA9F38CD1787C)
--- START_PARTICLE_FX_LOOPED_ON_PED_BONE
function Global.StartParticleFxLoopedOnPedBone(effectName, ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis)
	return fn(_ts(effectName), ped, xOffset, yOffset, zOffset, xRot, yRot, zRot, boneIndex, scale, xAxis, yAxis, zAxis, _ri)
end

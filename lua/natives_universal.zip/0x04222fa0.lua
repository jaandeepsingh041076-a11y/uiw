local fn = _gn(0xB50EB4CCB29704AC)
--- Removes the scubagear (for mp male: component id: 8, drawableId: 123, textureId: any) from peds. Does not play the 'remove scuba gear' animation, but instantly removes it.
-- @param ped The ped to remove the scuba gear from.
function Global.ClearPedScubaGearVariation(ped)
	return fn(ped)
end

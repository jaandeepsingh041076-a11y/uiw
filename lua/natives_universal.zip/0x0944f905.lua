local fn = _gn(0xF8C397922FC03F41)
--- Returns the convertible state of the specified vehicle.
-- ```cpp
-- enum eRoofState {
-- RAISED = 0,
-- LOWERING = 1,
-- LOWERED = 2,
-- RAISING = 3,
-- CLOSING_BOOT = 4,
-- ROOF_STUCK_RAISED = 5,
-- ROOF_STUCK_LOWERED = 6
-- }
-- ```
-- @param vehicle Vehicle to get the state of
-- @return Returns the current roof state, refer to `eRoofState`
function Global.GetConvertibleRoofState(vehicle)
	return fn(vehicle, _ri)
end

local fn = _gn(0x1C6CD14A876FFE39)
--- from armenian3.c4
-- TASK::TASK_PUT_PED_DIRECTLY_INTO_MELEE(PlayerPed, armenianPed, 0.0, -1.0, 0.0, 0);
function Global.TaskPutPedDirectlyIntoMelee(ped, meleeTarget, p2, p3, p4, p5)
	return fn(ped, meleeTarget, p2, p3, p4, p5)
end

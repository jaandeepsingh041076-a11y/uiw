local fn = _gn(0x7DCF7C708D292D55)
--- Max value for p1 is 15.
function Global.OverrideCamSplineMotionBlur(cam, p1, p2, p3)
	return fn(cam, p1, p2, p3)
end

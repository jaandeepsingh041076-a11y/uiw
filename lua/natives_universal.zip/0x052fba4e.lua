local fn = _gn(0x2B6D467DAB714E8D)
--- Makes a blip go small when off the minimap.
-- SET_BLIP_AS_*
function Global.N_0x2b6d467dab714e8d(blip, toggle)
	return fn(blip, toggle)
end

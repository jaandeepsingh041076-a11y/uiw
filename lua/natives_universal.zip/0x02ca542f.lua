local fn = _gn(0xB08B85D860E7BA3C)
--- SET_INCIDENT_REQUESTED_UNITS
function Global.SetIncidentRequestedUnits(incidentId, dispatchService, numUnits)
	return fn(incidentId, dispatchService, numUnits)
end

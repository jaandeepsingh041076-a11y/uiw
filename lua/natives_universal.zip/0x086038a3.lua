local fn = _gn(0x2597A0D4A4FC2C77)
--- NativeDB Introduced: v1290
function Global.NetworkEarnFromGangopsElite(amount, unk, actIndex)
	return fn(amount, _ts(unk), actIndex)
end

local fn = _gn(0x92C47782FDA8B2A3)
--- Only works with objects!
-- Network players do not see changes done with this.
function Global.CreateModelSwap(x, y, z, radius, originalModel, newModel, bSurviveMapReload)
	return fn(x, y, z, radius, _ch(originalModel), _ch(newModel), bSurviveMapReload)
end

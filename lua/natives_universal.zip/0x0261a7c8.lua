local fn = _gn(0x9FCB3CBFB3EAD69A)
--- SET_C\*
-- ```
-- NativeDB Introduced: v1734
-- ```
function Global.N_0x9fcb3cbfb3ead69a(p0, p1)
	return fn(p0, p1)
end

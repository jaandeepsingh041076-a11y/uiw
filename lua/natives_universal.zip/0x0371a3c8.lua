local fn = _gn(0x3EAE97309727E7AD)
--- NativeDB Introduced: v1734
function Global.PlaystatsCasinoBlackjack(p0)
	return fn(p0)
end

local fn = _gn(0xD1C55B110E4DF534)
--- SET_TV_???
function Global.N_0xd1c55b110e4df534(p0)
	return fn(p0)
end

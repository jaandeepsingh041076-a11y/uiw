local fn = _gn(0xBD2A8EC3AF4DE7DB)
--- Actually has 3 params, not 2.
-- p0: Ped
-- p1: int (or bool?)
-- p2: int
-- ```
-- ```
-- NativeDB Added Parameter 3: Any p2
function Global.TaskUseMobilePhone(ped, p1)
	return fn(ped, p1)
end

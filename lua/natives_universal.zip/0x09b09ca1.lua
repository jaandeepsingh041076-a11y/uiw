local fn = _gn(0x7B718E197453F2D9)
--- p1 is just an assumption. p2 was false and p3 was true.
function Global.NetworkBuyBounty(amount, victim, p2, p3)
	return fn(amount, victim, p2, p3)
end

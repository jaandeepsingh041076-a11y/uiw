local fn = _gn(0xD00D76A7DFC9D852)
--- Simply unloads the cutscene and doesn't do extra stuff that REMOVE_CUTSCENE does.
function Global.RemoveCutFile(cutsceneName)
	return fn(_ts(cutsceneName))
end

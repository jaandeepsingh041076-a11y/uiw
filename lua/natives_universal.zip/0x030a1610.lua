local fn = _gn(0x2A25ADC48F87841F)
--- PAUSE_MENU_IS_CONTEXT_MENU_ACTIVE
function Global.N_0x2a25adc48f87841f()
	return fn(_ri)
end

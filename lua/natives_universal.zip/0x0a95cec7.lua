local fn = _gn(0x112CEF1615A1139F)
--- _NET_GAMESERVER_DELETE_SET_TELEMETRY_NONCE_SEED
function Global.NetGameserverDeleteSetTelemetryNonceSeed()
	return fn(_r)
end

local fn = _gn(0x0EDEC3C276198689)
--- gets the network id of a ped
function Global.PedToNet(ped)
	return fn(ped, _ri)
end

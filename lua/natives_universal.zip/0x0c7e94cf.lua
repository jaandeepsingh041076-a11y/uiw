local fn = _gn(0xC38DC1E90D22547C)
--- LEADERBOARDS2_READ_RANK_PREDICTION
function Global.Leaderboards2ReadRankPrediction()
	return fn(_i, _i, _i, _r)
end

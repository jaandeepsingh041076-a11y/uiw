local fn = _gn(0xFE54B92A344583CA)
--- Sets how much the crane on the tow truck is raised, where 0.0 is fully lowered and 1.0 is fully raised.
function Global.SetTowTruckCraneHeight(vehicle, position)
	return fn(vehicle, position)
end

local fn = _gn(0x1CA3E9EAC9D93E5E)
--- SET_TEXT_DROP_SHADOW
function Global.SetTextDropShadow()
	return fn()
end

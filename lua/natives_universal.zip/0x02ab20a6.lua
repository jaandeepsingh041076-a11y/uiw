local fn = _gn(0x2485D34E50A22E84)
--- GOLF_TRAIL_SET_RADIUS
function Global.GolfTrailSetRadius(p0, p1, p2)
	return fn(p0, p1, p2)
end

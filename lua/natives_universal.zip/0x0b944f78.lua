local fn = _gn(0xA6D3A8750DC73270)
--- Used to set the tornado custom (convertible) rooftop livery.
-- Livery value that works for tornado custom is between 0 and 9 from what i can tell. Maybe 0-8 even.
-- Might work on other custom vehicles but im not sure what those might be, only confirmed it working with the tornado custom.
-- @param vehicle The vehicle handle.
-- @param livery Livery index.
function Global.SetVehicleRoofLivery(vehicle, livery)
	return fn(vehicle, livery)
end

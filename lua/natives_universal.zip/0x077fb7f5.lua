local fn = _gn(0x85796B0549DDE156)
--- Roll down all the windows of the vehicle passed through the first parameter.
function Global.RollDownWindows(vehicle)
	return fn(vehicle)
end

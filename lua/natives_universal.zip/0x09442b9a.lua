local fn = _gn(0x2FBF47B1B36D36F9)
--- NETWORK_SESSION_CANCEL_INVITE
function Global.NetworkSessionCancelInvite()
	return fn()
end

local fn = _gn(0xA9240A96C74CCA13)
--- UGC_GET_CONTENT_IS_VERIFIED
function Global.N_0xa9240a96c74cca13(p0)
	return fn(p0, _r)
end

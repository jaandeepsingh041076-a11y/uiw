local fn = _gn(0x55384438FC55AD8E)
--- Sets profile setting 935
function Global.N_0x55384438fc55ad8e(value)
	return fn(value)
end

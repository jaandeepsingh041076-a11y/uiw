local fn = _gn(0x01A358D9128B7A86)
--- GET_CURRENT_WEBPAGE_ID
function Global.N_0x01a358d9128b7a86()
	return fn(_ri)
end

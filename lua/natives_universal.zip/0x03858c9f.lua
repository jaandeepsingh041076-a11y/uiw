local fn = _gn(0x3F892CAF67444AE7)
--- NativeDB Added Parameter 8: Any p7
-- NativeDB Added Parameter 9: Any p8
-- @param dispatchService Refer to [ENABLE_DISPATCH_SERVICE](#\_0xDC0F817884CDD856) for dispatch types
function Global.CreateIncident(dispatchService, x, y, z, numUnits, radius, outIncidentID)
	return fn(dispatchService, x, y, z, numUnits, radius, _ii(outIncidentID) --[[ may be optional ]], _r)
end

local fn = _gn(0xC54C95DA968EC5B5)
--- SET_PLAYER_SIMULATE_AIMING
function Global.SetPlayerSimulateAiming(player, toggle)
	return fn(player, toggle)
end

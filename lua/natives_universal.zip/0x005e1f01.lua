local fn = _gn(0xE6A9F00D4240B519)
--- Adjusts a scaleform movie's dimensions to fit a large rendertarget. Mostly used in casino scripts.
function Global.SetScaleformMovieToUseSuperLargeRt(scaleformHandle, toggle)
	return fn(scaleformHandle, toggle)
end

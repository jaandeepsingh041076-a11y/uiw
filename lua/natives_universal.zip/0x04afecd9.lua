local fn = _gn(0x6856EC3D35C81EA4)
--- GET_TOTAL_SUCCESSFUL_STUNT_JUMPS
function Global.N_0x6856ec3d35c81ea4()
	return fn(_ri)
end

local fn = _gn(0xC843060B5765DCE7)
--- ASIN
-- @return Returns the inverse sine in radians of the specified value
function Global.Asin(value)
	return fn(value, _rf)
end

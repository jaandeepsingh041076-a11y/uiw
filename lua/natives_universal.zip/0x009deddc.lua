local fn = _gn(0xC5286FFC176F28A2)
--- IS_PED_RUNNING
function Global.IsPedRunning(ped)
	return fn(ped, _r)
end

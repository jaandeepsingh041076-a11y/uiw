local fn = _gn(0x163F8B586BC95F2A)
--- GET_COORDS_AND_ROTATION_OF_CLOSEST_OBJECT_OF_TYPE
function Global.N_0x163f8b586bc95f2a(x, y, z, radius, modelHash, rotationOrder)
	return fn(x, y, z, radius, _ch(modelHash), _v, _v, rotationOrder, _ri)
end

local fn = _gn(0x31125FD509D9043F)
--- **This native does absolutely nothing, just a nullsub**
function Global.N_0x31125fd509d9043f(p0)
	return fn(_ii(p0) --[[ may be optional ]])
end

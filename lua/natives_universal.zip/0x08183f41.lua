local fn = _gn(0x9A2C8064B6C1E41A)
--- SC_INBOX_MESSAGE_DO_APPLY
function Global.ScInboxMessagePush(p0)
	return fn(p0, _r)
end

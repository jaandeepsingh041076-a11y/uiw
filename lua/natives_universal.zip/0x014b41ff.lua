local fn = _gn(0x5F3B7749C112D552)
--- SUPPRESS_AGITATION_EVENTS_NEXT_FRAME
function Global.SuppressAgitationEventsNextFrame()
	return fn()
end

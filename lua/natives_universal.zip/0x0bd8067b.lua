local fn = _gn(0xED712CA327900C8A)
--- Refer to [`SET_WEATHER_TYPE_NOW`](#\_0x29B487C359E19889) for weather types.
function Global.SetWeatherTypeNowPersist(weatherType)
	return fn(_ts(weatherType))
end

local fn = _gn(0xCC9682B8951C5229)
--- Preview: https://gfycat.com/MaleRareAmazonparrot
-- @param id From 0 to 3.
function Global.N_0xcc9682b8951c5229(ped, r, g, b, id)
	return fn(ped, r, g, b, id)
end

local fn = _gn(0xCADA5A0D0702381E)
--- PLAY_DEFERRED_SOUND_FRONTEND
function Global.PlayDeferredSoundFrontend(soundName, soundsetName)
	return fn(_ts(soundName), _ts(soundsetName))
end

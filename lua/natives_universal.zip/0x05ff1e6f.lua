local fn = _gn(0x598dd6ae)
--- A setter for the accuracy spread of a weapon.
-- @param weaponHash Weapon name hash.
-- @param spread Accuracy spread
function Global.SetWeaponAccuracySpread(weaponHash, spread)
	return fn(_ch(weaponHash), spread)
end

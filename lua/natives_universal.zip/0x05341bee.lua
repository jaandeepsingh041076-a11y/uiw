local fn = _gn(0x2AA720E4287BF269)
--- Sets the neon lights of the specified vehicle on/off.
-- Indices:
-- 0 = Left
-- 1 = Right
-- 2 = Front
-- 3 = Back
function Global.SetVehicleNeonLightEnabled(vehicle, index, toggle)
	return fn(vehicle, index, toggle)
end

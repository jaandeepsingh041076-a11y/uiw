local fn = _gn(0x8378627201D5497D)
--- SET_PED_CHANCE_OF_FIRING_BLANKS
function Global.SetPedChanceOfFiringBlanks(ped, xBias, yBias)
	return fn(ped, xBias, yBias)
end

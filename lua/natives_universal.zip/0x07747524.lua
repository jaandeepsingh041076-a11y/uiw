local fn = _gn(0x9489659372A81585)
--- 0x9489659372A81585
-- @return Hard-coded to always return 0.
function Global.N_0x9489659372a81585()
	return fn(_r)
end

local fn = _gn(0x5FBCA48327B914DF)
--- Adds the GTA: Online player heading indicator to a blip.
function Global.N_0x5fbca48327b914df(blip, toggle)
	return fn(blip, toggle)
end

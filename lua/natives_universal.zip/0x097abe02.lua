local fn = _gn(0x5486A79D9FBD342D)
--- GET_JACK_TARGET
function Global.GetJackTarget(ped)
	return fn(ped, _ri)
end

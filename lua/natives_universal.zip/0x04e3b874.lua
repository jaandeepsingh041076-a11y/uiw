local fn = _gn(0xD830567D88A1E873)
--- NETWORK_SET_ENTITY_CAN_BLEND
function Global.NetworkSetEntityCanBlend(entity, toggle)
	return fn(entity, toggle)
end

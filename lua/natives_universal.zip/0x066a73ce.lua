local fn = _gn(0x2B5E102E4A42F2BF)
--- GET_STATUS_OF_MISSION_REPEAT_SAVE
function Global.N_0x2b5e102e4a42f2bf()
	return fn(_ri)
end

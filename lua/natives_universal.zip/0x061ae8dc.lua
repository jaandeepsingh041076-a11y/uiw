local fn = _gn(0x5F43D83FD6738741)
--- IS_PLAYER_VEH_RADIO_ENABLE
function Global.IsPlayerVehicleRadioEnabled()
	return fn(_r)
end

local fn = _gn(0x4a9eede6)
--- Sets default invincible value for specific health config.
-- @param configName Name of health config.
-- @param newValue Value
function Global.SetHealthConfigInvincible(configName, newValue)
	return fn(_ts(configName), newValue)
end

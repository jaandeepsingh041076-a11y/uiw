local fn = _gn(0x6671F3EEC681BDA1)
--- TASK_AIM_GUN_AT_COORD
function Global.TaskAimGunAtCoord(ped, x, y, z, time, bInstantBlendToAim, bPlayAimIntro)
	return fn(ped, x, y, z, time, bInstantBlendToAim, bPlayAimIntro)
end

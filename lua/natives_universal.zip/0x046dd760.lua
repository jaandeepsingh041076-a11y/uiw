local fn = _gn(0x5AFEEDD9BB2899D7)
--- SET_VEHICLE_PROVIDES_COVER
function Global.SetVehicleProvidesCover(vehicle, toggle)
	return fn(vehicle, toggle)
end

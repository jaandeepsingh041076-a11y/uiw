local fn = _gn(0x271401846BD26E92)
--- Sets the ambient ped & vehicle population spawning origin to be based around the active scripted camera for this frame
-- This will prevent vehicles from being created close to the camera and/or on-screen
function Global.N_0x271401846bd26e92(vehicles, peds)
	return fn(vehicles, peds)
end

local fn = _gn(0xD5BB406F4E04019F)
--- NETWORK_SPENT_NO_COPS
function Global.N_0xd5bb406f4e04019f(p0, p1, p2)
	return fn(p0, p1, p2)
end

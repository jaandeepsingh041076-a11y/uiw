local fn = _gn(0xBBDA792448DB5A89)
--- TO_FLOAT
function Global.ToFloat(value)
	return fn(value, _rf)
end

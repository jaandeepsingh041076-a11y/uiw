local fn = _gn(0x7A983AA9DA2659ED)
--- DATADICT_GET_ARRAY
function Global.ObjectValueGetArray(key)
	return fn(_i, _ts(key), _rl)
end

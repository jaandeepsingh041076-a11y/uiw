local fn = _gn(0x05A42BA9FC8DA96B)
--- _GET_NAME_OF_THREAD
function Global.GetNameOfThread(threadId)
	return fn(threadId, _s)
end

local fn = _gn(0x24409FC4C55CB22D)
--- NETWORK_GET_PRESENCE_INVITE_CONTENT_ID
function Global.N_0x24409fc4c55cb22d(p0)
	return fn(p0, _s)
end

local fn = _gn(0x8F5EBAB1F260CFCE)
--- GET_VEHICLE_LOCK_ON_TARGET
function Global.GetVehicleOwner(vehicle, entity)
	return fn(vehicle, _ii(entity) --[[ may be optional ]], _r)
end

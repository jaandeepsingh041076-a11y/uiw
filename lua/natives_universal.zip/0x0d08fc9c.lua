local fn = _gn(0x5F35F6732C3FBBA0)
--- GET_FINAL_RENDERED_IN_WHEN_FRIENDLY_FOV
function Global.GetFinalRenderedInWhenFriendlyFov(player)
	return fn(player, _rf)
end

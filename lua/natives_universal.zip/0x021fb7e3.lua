local fn = _gn(0x2F395D61F3A1F877)
--- GET_PLAYER_CURRENT_STEALTH_NOISE
function Global.GetPlayerCurrentStealthNoise(player)
	return fn(player, _rf)
end

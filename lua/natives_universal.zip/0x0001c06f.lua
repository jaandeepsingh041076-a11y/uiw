local fn = _gn(0xE4B5F4BF2CB24E65)
--- HAS_ACTION_MODE_ASSET_LOADED
function Global.HasActionModeAssetLoaded(asset)
	return fn(_ts(asset), _r)
end

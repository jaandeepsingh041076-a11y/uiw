local fn = _gn(0x1C7302E725259789)
--- DOES_TEXT_BLOCK_EXIST
function Global.DoesTextBlockExist(gxt)
	return fn(_ts(gxt), _r)
end

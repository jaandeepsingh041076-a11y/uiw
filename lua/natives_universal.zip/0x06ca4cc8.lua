local fn = _gn(0x88CBB5CEB96B7BD2)
--- p1 is usually 0 in the scripts. action is either 0 or a pointer to "DEFAULT_ACTION".
function Global.SetPedStealthMovement(ped, p1, action)
	return fn(ped, p1, _ts(action))
end

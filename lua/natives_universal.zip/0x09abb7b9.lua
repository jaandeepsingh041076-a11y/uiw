local fn = _gn(0x4A7D6E727F941747)
--- 0x4A7D6E727F941747
function Global.N_0x4a7d6e727f941747(p0)
	return fn(_ii(p0) --[[ may be optional ]], _ri)
end

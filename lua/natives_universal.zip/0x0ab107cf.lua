local fn = _gn(0x0FF2862B61A58AF9)
--- p0 is always false in scripts.
function Global.N_0x0ff2862b61a58af9(toggle)
	return fn(toggle)
end

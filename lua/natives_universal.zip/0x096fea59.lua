local fn = _gn(0x6B1E8E2ED1335B71)
--- This function sets metadata of type bool to specified entity.
function Global.DecorSetBool(entity, propertyName, value)
	return fn(entity, _ts(propertyName), value, _r)
end

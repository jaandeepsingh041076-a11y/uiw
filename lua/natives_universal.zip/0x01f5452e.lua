local fn = _gn(0x61767F73EACEED21)
--- WAS_PED_KNOCKED_OUT
function Global.N_0x61767f73eaceed21(ped)
	return fn(ped, _r)
end

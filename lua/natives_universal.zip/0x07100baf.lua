local fn = _gn(0xF5F1E89A970B7796)
--- NativeDB Introduced: v1493
function Global.N_0xf5f1e89a970b7796()
	return fn(_r)
end

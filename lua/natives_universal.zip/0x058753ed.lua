local fn = _gn(0xC4278F70131BAA6D)
--- Must be toggled before being queued for animation
function Global.SetBlipDisplayIndicatorOnBlip(blip, toggle)
	return fn(blip, toggle)
end

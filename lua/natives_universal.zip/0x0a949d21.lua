local fn = _gn(0x57C5DB656185EAC4)
--- Changing traffic-lights will not change the behavior of NPCs.
-- Example: [here](https://www.gtaforums.com/topic/830463-help-with-turning-lights-green-and-causing-peds-to-crash-into-each-other/#entry1068211340)
-- ```cpp
-- enum eTrafficlightOverrideMode
-- {
-- TLO_RED = 0,
-- TLO_AMBER = 1,
-- TLO_GREEN = 2,
-- TLO_NONE = 3
-- }
-- ```
function Global.SetEntityTrafficlightOverride(entity, state)
	return fn(entity, state)
end

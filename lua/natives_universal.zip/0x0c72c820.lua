local fn = _gn(0x7E2F4E8F44CAF4E0)
--- NativeDB Introduced: v2699
function Global.NetworkSpentSalesDisplay(p0)
	return fn(p0)
end

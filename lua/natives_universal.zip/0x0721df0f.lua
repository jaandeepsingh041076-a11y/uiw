local fn = _gn(0xCAA15F13EBD417FF)
--- SET_NUMBER_OF_PARKED_VEHICLES
function Global.SetNumberOfParkedVehicles(value)
	return fn(value)
end

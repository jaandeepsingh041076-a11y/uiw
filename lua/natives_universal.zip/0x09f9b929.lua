local fn = _gn(0x1121BFA1A1A522A8)
--- Doesn't actually return anything.
function Global.N_0x1121bfa1a1a522a8()
	return fn(_ri)
end

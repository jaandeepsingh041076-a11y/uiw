local fn = _gn(0x327EDEEEAC55C369)
--- IS_HELP_MESSAGE_FADING_OUT
function Global.IsHelpMessageFadingOut()
	return fn(_r)
end

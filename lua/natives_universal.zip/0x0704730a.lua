local fn = _gn(0x99C82F8A139F3E4E)
--- SET_VEHICLE_KERS_ALLOWED
function Global.SetVehicleKersAllowed(vehicle, toggle)
	return fn(vehicle, toggle)
end

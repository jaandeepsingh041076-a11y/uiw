local fn = _gn(0xEB709A36958ABE0D)
--- When this native returns true, do not call [`SET_MP_GAMER_TAG_NAME`](#\_0xDEA2B8283BAA3944).
-- @param playerId Local ID of the player.
-- @return Returns if game code is currently updating gamer tag and crew details for a player's name tag.
function Global.N_0xeb709a36958abe0d(playerId)
	return fn(playerId, _r)
end

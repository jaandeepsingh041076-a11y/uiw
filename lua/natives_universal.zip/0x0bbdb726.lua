local fn = _gn(0x694E00132F2823ED)
--- SET_ENTITY_REQUIRES_MORE_EXPENSIVE_RIVER_CHECK
function Global.N_0x694e00132f2823ed(entity, toggle)
	return fn(entity, toggle)
end

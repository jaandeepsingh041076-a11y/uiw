local fn = _gn(0x69FF13266D7296DA)
--- STAT_SET_LICENSE_PLATE
function Global.StatSetLicensePlate(statName, str)
	return fn(_ch(statName), _ts(str), _r)
end

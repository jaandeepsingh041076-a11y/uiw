local fn = _gn(0xD12882D3FF82BF11)
--- Clears all active blip routes that have been set with [`SetBlipRoute`](#\_0x4F7D8A9BFB0B43E9).
function Global.ClearAllBlipRoutes()
	return fn()
end

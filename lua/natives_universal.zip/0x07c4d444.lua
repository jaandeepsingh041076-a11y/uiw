local fn = _gn(0xEC03C719DB2F4306)
--- NETWORK_SPENT_CARWASH
function Global.NetworkSpentCarwash(p0, p1, p2, p3, p4)
	return fn(p0, p1, p2, p3, p4)
end

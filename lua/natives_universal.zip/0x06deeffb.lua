local fn = _gn(0xC7848EFCCC545182)
--- SET_CAM_NEAR_CLIP
function Global.SetCamNearClip(cam, nearClip)
	return fn(cam, nearClip)
end

local fn = _gn(0xC8E9B6B71B8E660D)
--- ```
-- NativeDB Introduced: v1604
-- NativeDB Added Parameter 2 (2060): float durationMod : A multiplier applied to the default nitrous duration (default is 3 seconds).
-- NativeDB Added Parameter 3 (2060): float power : A multiplier applied to the default nitrous power multiplier (default is 3).
-- NativeDB Added Parameter 4 (2060): float rechargeTime : A multiplier applied to the default nitrous recharge rate.
-- NativeDB Added Parameter 5 (2060): BOOL disableSound : A boolean to disable the default nitrous sound when the nitrous is active.
-- ```
-- Overrides the default settings of a vehicle's nitrous system, allowing custom control over its performance characteristics.
-- @param vehicle The vehicle whose nitrous system is to be overridden.
-- @param override A boolean toggle to enable or disable the override settings.
function Global.SetOverrideNitrousLevel(vehicle, override)
	return fn(vehicle, override)
end

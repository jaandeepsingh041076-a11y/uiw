local fn = _gn(0x3CF48F6F96E749DC)
--- SET_CAM_DOF_PLANES
function Global.SetCamDofPlanes(cam, p1, p2, p3, p4)
	return fn(cam, p1, p2, p3, p4)
end

local fn = _gn(0x1185A8087587322C)
--- Toggles if the text input box can be opened with [`DISPLAY_ONSCREEN_KEYBOARD`](#\_0x00DC833F2568DBF6).
function Global.N_0x1185a8087587322c(state)
	return fn(state)
end

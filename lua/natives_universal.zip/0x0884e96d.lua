local fn = _gn(0xB48FCED898292E52)
--- Example:
-- OBJECT::GET_RAYFIRE_MAP_OBJECT(-809.9619750976562, 170.919, 75.7406997680664, 3.0, "des_tvsmash");
function Global.GetDesObject(x, y, z, radius, name)
	return fn(x, y, z, radius, _ts(name), _ri)
end

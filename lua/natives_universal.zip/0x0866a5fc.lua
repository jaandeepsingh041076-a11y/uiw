local fn = _gn(0x92659B4CE1863CB3)
--- GET_PLAYER_MAX_ARMOUR
function Global.GetPlayerMaxArmour(player)
	return fn(player, _ri)
end

local fn = _gn(0x52C1EADAF7B10302)
--- NETWORK_GET_*
-- NativeDB Introduced: v323
function Global.NetworkGetOldestResendCountForPlayer(player)
	return fn(player, _ri)
end

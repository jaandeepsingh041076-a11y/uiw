local fn = _gn(0xB9BB18E2C40142ED)
--- LEADERBOARDS_CACHE_DATA_ROW
function Global.LeaderboardsCacheDataRow(p0)
	return fn(_ii(p0) --[[ may be optional ]], _r)
end

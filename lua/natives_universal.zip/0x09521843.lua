local fn = _gn(0x79AB33F0FBFAC40C)
--- PLAYSTATS_ACQUIRED_HIDDEN_PACKAGE
function Global.N_0x79ab33f0fbfac40c(p0)
	return fn(p0)
end

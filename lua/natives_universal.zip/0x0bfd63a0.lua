local fn = _gn(0xFB680D403909DC70)
--- 0xFB680D403909DC70
function Global.N_0xfb680d403909dc70(p0, p1)
	return fn(p0, p1)
end

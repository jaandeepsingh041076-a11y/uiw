local fn = _gn(0x35F7DD45E8C0A16D)
--- IS_INTERIOR_ENTITY_SET_ACTIVE
function Global.N_0x35f7dd45e8c0a16d(interior, entitySetName)
	return fn(interior, _ts(entitySetName), _r)
end

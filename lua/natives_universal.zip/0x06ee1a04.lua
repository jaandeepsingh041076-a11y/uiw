local fn = _gn(0xC55854C7D7274882)
--- DATAFILE_FLUSH_MISSION_HEADER
function Global.N_0xc55854c7d7274882()
	return fn()
end

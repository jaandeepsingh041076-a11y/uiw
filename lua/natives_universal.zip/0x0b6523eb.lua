local fn = _gn(0xCD67AD041A394C9C)
--- UGC_GET_CONTENT_USER_ID
function Global.N_0xcd67ad041a394c9c(p0)
	return fn(p0, _s)
end

local fn = _gn(0x1EAF30FCFBF5AF74)
--- Returns true if the id is non zero.
function Global.IsVehicleNodeIdValid(vehicleNodeId)
	return fn(vehicleNodeId, _r)
end

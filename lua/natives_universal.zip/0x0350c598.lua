local fn = _gn(0x032D49C5E359C847)
--- SET_ANIM_RATE
function Global.SetAnimRate(p0, p1, p2, p3)
	return fn(p0, p1, p2, p3)
end

local fn = _gn(0x6EA72622)
function Global.IsCarWaitingForWorldCollision(vehicle)
	return fn(vehicle, _r)
end

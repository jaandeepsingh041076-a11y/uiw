local fn = _gn(0x499700EF)
function Global.SetDriveTaskCruiseSpeed(ped, speed)
	return fn(ped, speed)
end

local fn = _gn(0x01A05ADD)
function Global.ConvertMetresToFeetInt(metres)
	return fn(metres, _ri)
end

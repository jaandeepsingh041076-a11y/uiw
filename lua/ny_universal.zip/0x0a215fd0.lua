local fn = _gn(0x57F7558B)
function Global.GetGameViewportId(viewportid)
	return fn(_ii(viewportid) --[[ may be optional ]])
end

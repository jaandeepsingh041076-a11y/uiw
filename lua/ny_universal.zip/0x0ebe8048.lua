local fn = _gn(0x75A648B7)
function Global.Absi(value)
	return fn(value, _rf)
end

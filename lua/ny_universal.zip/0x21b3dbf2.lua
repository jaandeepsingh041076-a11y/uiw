local fn = _gn(0x226A7227)
function Global.SetCutsceneExtraRoomPos(x, y, z)
	return fn(x, y, z)
end

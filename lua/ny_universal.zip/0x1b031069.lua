local fn = _gn(0x26747EBE)
function Global.PlaystatsMissionStarted(Unk797)
	return fn(Unk797)
end

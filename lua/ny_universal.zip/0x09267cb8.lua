local fn = _gn(0x2B2E39BB)
function Global.PrintBigQ(gxtentry, time, flag)
	return fn(_ts(gxtentry), time, flag)
end

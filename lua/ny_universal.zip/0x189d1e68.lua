local fn = _gn(0x25AC586E)
function Global.SetDitchPoliceModels(set)
	return fn(set)
end

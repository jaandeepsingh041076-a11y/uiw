local fn = _gn(0x517B7068)
function Global.IsScoreGreater(playerIndex, score)
	return fn(playerIndex, score, _r)
end

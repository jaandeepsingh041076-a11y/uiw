local fn = _gn(0x318F65E6)
function Global.IsReplaySystemSaving()
	return fn(_r)
end

local fn = _gn(0x1DD624A0)
function Global.HasCharBeenDamagedByChar(ped, otherChar, unknownFalse)
	return fn(ped, otherChar, unknownFalse, _r)
end

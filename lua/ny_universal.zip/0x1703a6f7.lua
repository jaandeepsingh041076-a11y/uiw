local fn = _gn(0x1DFF5B06)
function Global.StoreScriptValuesForNetworkGame(Unk998)
	return fn(Unk998)
end

local fn = _gn(0x0B464BE8)
function Global.HasObjectBeenDamagedByChar(obj, ped)
	return fn(obj, ped, _r)
end

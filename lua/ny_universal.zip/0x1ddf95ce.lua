local fn = _gn(0x5EA84115)
function Global.SetCharNeverTargetted(ped, set)
	return fn(ped, set)
end

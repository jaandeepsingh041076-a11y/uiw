local fn = _gn(0x2E5C36C0)
function Global.SetCharCantBeDraggedOut(ped, enabled)
	return fn(ped, enabled)
end

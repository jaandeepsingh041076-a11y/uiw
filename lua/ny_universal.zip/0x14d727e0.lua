local fn = _gn(0x61822A3C)
function Global.SetCharRelationshipGroup(ped, relationshipGroup)
	return fn(ped, relationshipGroup)
end

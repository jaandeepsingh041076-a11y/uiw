local fn = _gn(0x615959BA)
function Global.SetSpritesDrawBeforeFade(set)
	return fn(set)
end

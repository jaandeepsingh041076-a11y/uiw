local fn = _gn(0x47F971E8)
function Global.SetFilterSaveSetting(filterid, setting)
	return fn(filterid, setting)
end

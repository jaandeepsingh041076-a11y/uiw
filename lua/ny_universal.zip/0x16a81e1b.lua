local fn = _gn(0x42DB145F)
function Global.ClearCharRelationship(ped, reltype, relgroup)
	return fn(ped, reltype, relgroup)
end

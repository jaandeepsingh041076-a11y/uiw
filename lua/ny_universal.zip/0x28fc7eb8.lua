local fn = _gn(0x3EA0648D)
function Global.EnableScriptControlledMicrophone()
	return fn(_r)
end

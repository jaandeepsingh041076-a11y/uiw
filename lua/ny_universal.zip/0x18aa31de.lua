local fn = _gn(0x1B8E7EED)
function Global.IsInLanMode()
	return fn(_r)
end

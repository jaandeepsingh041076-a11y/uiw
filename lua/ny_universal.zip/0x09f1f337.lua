local fn = _gn(0x6C4568A7)
function Global.IsPauseMenuActive()
	return fn(_r)
end

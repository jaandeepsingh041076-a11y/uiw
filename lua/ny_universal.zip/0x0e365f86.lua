local fn = _gn(0x40035D5D)
function Global.SetInSpectatorMode(spectate)
	return fn(spectate)
end

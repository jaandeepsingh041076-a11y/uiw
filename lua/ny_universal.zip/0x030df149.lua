local fn = _gn(0x48726B45)
function Global.NetworkHaveSummons()
	return fn(_r)
end

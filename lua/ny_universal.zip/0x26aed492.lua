local fn = _gn(0x49A75618)
function Global.IsStringNull(str)
	return fn(_ts(str), _r)
end

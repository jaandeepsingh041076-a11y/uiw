local fn = _gn(0x7EAC3387)
function Global.IsCamPropagating(camera)
	return fn(camera, _r)
end

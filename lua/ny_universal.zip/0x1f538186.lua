local fn = _gn(0x57E37103)
function Global.ForceRandomPedType(type)
	return fn(type)
end

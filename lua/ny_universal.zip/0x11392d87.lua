local fn = _gn(0x486F3D93)
function Global.PlayAudioEvent(name)
	return fn(_ts(name))
end

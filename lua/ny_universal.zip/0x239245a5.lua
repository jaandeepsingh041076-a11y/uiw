local fn = _gn(0x0A76502F)
function Global.TriggerPtfxOnPed(name, ped, x, y, z, Unk1071, Unk1072, Unk1073, flags)
	return fn(_ts(name), ped, x, y, z, Unk1071, Unk1072, Unk1073, flags, _r)
end

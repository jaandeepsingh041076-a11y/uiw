local fn = _gn(0x18246AC8)
function Global.GetAudibleMusicTrackTextId()
	return fn(_ri)
end

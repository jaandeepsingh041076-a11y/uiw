local fn = _gn(0x282D2CAA)
function Global.NetworkGetFindResult(Unk925, Unk926)
	return fn(Unk925, Unk926)
end

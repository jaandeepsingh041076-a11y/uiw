local fn = _gn(0x1788346E)
function Global.FinishStreamingRequestList()
	return fn()
end

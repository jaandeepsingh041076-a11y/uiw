local fn = _gn(0x69f7c29e)
--- Gets if the specified `rawKeyIndex` is pressed on the keyboard.
-- This will not be triggered if the key is disabled with [DISABLE_RAW_KEY_THIS_FRAME](#\_0x8BCF0014)
-- Virtual key codes can be found [here](https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes)
-- @param rawKeyIndex Index of raw key from keyboard.
-- @return Returns bool value of pressed state.
function Global.IsRawKeyPressed(rawKeyIndex)
	return fn(rawKeyIndex, _r)
end

local fn = _gn(0x1C132038)
function Global.IsCharTryingToEnterALockedCar(ped)
	return fn(ped, _r)
end

local fn = _gn(0x5E564CFF)
function Global.AttachCamToVehicle(cam, veh)
	return fn(cam, veh)
end

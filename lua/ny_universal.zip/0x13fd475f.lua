local fn = _gn(0x141B23A9)
function Global.IsCarStoppedAtTrafficLights(vehicle)
	return fn(vehicle, _r)
end

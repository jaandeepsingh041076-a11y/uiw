local fn = _gn(0x31017E6E)
function Global.SetCarWatertight(car, set)
	return fn(car, set)
end

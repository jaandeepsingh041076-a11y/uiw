local fn = _gn(0x5D786EEE)
function Global.ExtinguishCharFire(ped)
	return fn(ped)
end

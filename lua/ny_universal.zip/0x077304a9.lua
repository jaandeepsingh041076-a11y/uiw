local fn = _gn(0x2F0718CA)
function Global.UnlockMissionNewsStory(id)
	return fn(id)
end

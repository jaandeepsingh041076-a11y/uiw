local fn = _gn(0x3E5B7E59)
function Global.UnfreezeRadioStation(radiostation)
	return fn(_ts(radiostation))
end

local fn = _gn(0x7F7B4FC5)
function Global.LoadCharDecisionMaker(type, pDM)
	return fn(type, _ii(pDM) --[[ may be optional ]])
end

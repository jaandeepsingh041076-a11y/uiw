local fn = _gn(0x5873667B)
function Global.NetworkStartSessionSucceeded()
	return fn(_r)
end

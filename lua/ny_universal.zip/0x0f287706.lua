local fn = _gn(0x4859273F)
function Global.IsPedLookingAtCar(ped, car)
	return fn(ped, car, _r)
end

local fn = _gn(0x051A131D)
function Global.GetIdOfThisThread()
	return fn(_ri)
end

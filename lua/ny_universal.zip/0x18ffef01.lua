local fn = _gn(0x31D53B3D)
function Global.SetCameraAutoScriptActivation(set)
	return fn(set)
end

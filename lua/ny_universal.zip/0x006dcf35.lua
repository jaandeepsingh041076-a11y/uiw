local fn = _gn(0x499C0C01)
function Global.TaskSetCombatDecisionMaker(ped, dm)
	return fn(ped, dm)
end

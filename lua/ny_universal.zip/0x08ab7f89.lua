local fn = _gn(0x17901684)
function Global.ResurrectNetworkPlayer(playerIndex, x, y, z, ukn0)
	return fn(playerIndex, x, y, z, ukn0)
end

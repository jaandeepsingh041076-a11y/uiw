local fn = _gn(0x2232704D)
function Global.IncreasePlayerMaxArmour(player, armour)
	return fn(player, armour)
end

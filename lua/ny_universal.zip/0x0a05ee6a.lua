local fn = _gn(0x143358D3)
function Global.TaskSeekCoverToCoverPoint(ped, Unk412, Unk413, Unk414, Unk415, Unk416)
	return fn(ped, Unk412, Unk413, Unk414, Unk415, Unk416)
end

local fn = _gn(0x66F47727)
function Global.AddWidgetToggle(Unk1107, Unk1108)
	return fn(Unk1107, Unk1108)
end

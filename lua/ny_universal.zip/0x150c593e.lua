local fn = _gn(0x14790F9F)
function Global.SetPoliceRadarBlips(set)
	return fn(set)
end

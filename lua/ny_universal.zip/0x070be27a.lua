local fn = _gn(0x2BA92322)
function Global.SetPedForceVisualiseHeadDamageFromBullets(ped, set)
	return fn(ped, set)
end

local fn = _gn(0x009641EE)
function Global.CountScriptCamsByTypeAndOrState(type, Unk536, Unk537)
	return fn(type, Unk536, Unk537, _ri)
end

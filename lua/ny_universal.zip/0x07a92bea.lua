local fn = _gn(0x4ECB2267)
function Global.IsCharInjured(ped)
	return fn(ped, _r)
end

local fn = _gn(0x63B87EBE)
function Global.DontDispatchCopsForPlayer(player, dont)
	return fn(player, dont)
end

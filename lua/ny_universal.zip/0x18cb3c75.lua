local fn = _gn(0x60E335FA)
function Global.SetHasBeenOwnedForCarGenerator(CarGen, set)
	return fn(CarGen, set)
end

local fn = _gn(0x7783449D)
function Global.AwardPlayerMissionRespect(respect)
	return fn(respect)
end

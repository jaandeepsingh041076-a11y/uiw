local fn = _gn(0x61040B08)
function Global.ActivateReplayMenu()
	return fn()
end

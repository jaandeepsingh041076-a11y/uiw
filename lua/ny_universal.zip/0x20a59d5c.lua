local fn = _gn(0x418D0889)
function Global.SetNoResprays(set)
	return fn(set)
end

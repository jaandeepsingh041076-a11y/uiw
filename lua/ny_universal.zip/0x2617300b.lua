local fn = _gn(0x61A812F5)
function Global.PedQueueRejectPedsWithFlagFalse(flagid)
	return fn(flagid)
end

local fn = _gn(0x2C18736E)
function Global.TaskDrivePointRoute(ped, point, radius)
	return fn(ped, point, radius)
end

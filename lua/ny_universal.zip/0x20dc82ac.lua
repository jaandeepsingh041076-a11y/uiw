local fn = _gn(0x28A73BCA)
function Global.IsCharInTaxi(ped)
	return fn(ped, _r)
end

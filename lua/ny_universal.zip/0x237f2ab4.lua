local fn = _gn(0x4FB069ED)
function Global.SetHelpMessageBoxSize(Unk773)
	return fn(Unk773)
end

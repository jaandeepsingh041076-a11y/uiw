local fn = _gn(0x5DC456DE)
function Global.SetCharMoveAnimSpeedMultiplier(ped, multiplier)
	return fn(ped, multiplier)
end

local fn = _gn(0x0F0269B5)
function Global.GetIsWidescreen()
	return fn(_r)
end

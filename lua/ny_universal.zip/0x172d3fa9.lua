local fn = _gn(0x37871A37)
function Global.SetMovieTime(time)
	return fn(time)
end

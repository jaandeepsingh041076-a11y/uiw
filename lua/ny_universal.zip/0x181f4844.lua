local fn = _gn(0x131A0C84)
function Global.TaskCombatRoll(ped, Unk191)
	return fn(ped, Unk191)
end

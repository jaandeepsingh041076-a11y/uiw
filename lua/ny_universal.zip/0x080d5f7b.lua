local fn = _gn(0x6F766824)
function Global.GetNthClosestCarNodeFavourDirection(Unk810, x, y, z, n)
	return fn(Unk810, x, y, z, n, _f, _f, _f, _f, _r)
end

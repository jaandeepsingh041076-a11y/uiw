local fn = _gn(0x6C63251D)
function Global.TaskGetOffBoat(ped, timeout)
	return fn(ped, timeout)
end

local fn = _gn(0x764236CE)
function Global.SecuromSpotCheck4()
	return fn(_r)
end

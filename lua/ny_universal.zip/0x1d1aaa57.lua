local fn = _gn(0x02033258)
function Global.SetNextDesiredMoveState(state)
	return fn(state)
end

local fn = _gn(0x0BCE3423)
function Global.IsPedAttachedToObject(ped, obj)
	return fn(ped, obj, _r)
end

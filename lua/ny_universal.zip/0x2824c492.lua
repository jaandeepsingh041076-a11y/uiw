local fn = _gn(0x052A30F7)
function Global.IsThreadActive(threadId)
	return fn(threadId, _r)
end

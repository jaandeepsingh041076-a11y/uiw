local fn = _gn(0x446E6515)
function Global.AddToPreviousBrief(gxtentry)
	return fn(_ts(gxtentry))
end

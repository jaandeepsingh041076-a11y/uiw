local fn = _gn(0x5C422066)
function Global.GetCharReadyToBeStunned(ped)
	return fn(ped, _r)
end

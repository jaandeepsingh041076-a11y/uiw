local fn = _gn(0x6AC52840)
function Global.GetCurrentStackSize()
	return fn(_ri)
end

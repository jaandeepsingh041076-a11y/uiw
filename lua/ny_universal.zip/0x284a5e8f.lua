local fn = _gn(0x60320FEB)
function Global.HideHudAndRadarThisFrame()
	return fn()
end

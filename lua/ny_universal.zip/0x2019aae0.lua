local fn = _gn(0x74F97CF8)
function Global.GetPedPathWillAvoidDynamicObjects(ped)
	return fn(ped, _r)
end

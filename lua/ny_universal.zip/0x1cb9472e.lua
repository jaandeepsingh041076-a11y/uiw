local fn = _gn(0x43F5151F)
function Global.TaskWanderStandard(ped)
	return fn(ped)
end

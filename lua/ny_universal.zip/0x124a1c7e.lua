local fn = _gn(0x19976813)
function Global.GetIsHidef()
	return fn(_r)
end

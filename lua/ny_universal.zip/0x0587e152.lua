local fn = _gn(0x15012850)
function Global.TaskCombatHatedTargetsAroundCharTimed(ped, radius, duration)
	return fn(ped, radius, duration)
end

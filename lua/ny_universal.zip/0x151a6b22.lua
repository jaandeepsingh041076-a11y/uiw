local fn = _gn(0x3F413561)
function Global.SetEngineHealth(vehicle, health)
	return fn(vehicle, health)
end

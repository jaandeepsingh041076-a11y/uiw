local fn = _gn(0x59EE3A11)
function Global.IsScreenFadedOut()
	return fn(_r)
end

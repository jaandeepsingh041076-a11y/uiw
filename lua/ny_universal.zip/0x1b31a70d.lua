local fn = _gn(0x2E12687B)
function Global.AnchorBoat(boat, anchor)
	return fn(boat, anchor)
end

local fn = _gn(0x203A137B)
function Global.GenerateDirections(x, y, z)
	return fn(x, y, z, _i, _v)
end

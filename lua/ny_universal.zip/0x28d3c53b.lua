local fn = _gn(0x4CC81FCB)
function Global.SetHintTimes(Unk580, Unk581, Unk582)
	return fn(Unk580, Unk581, Unk582)
end

local fn = _gn(0x26AA20CF)
function Global.ClearPlayerHasDamagedAtLeastOneVehicle(player)
	return fn(player)
end

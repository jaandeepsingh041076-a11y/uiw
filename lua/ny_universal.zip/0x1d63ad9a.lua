local fn = _gn(0x391E4575)
function Global.NetworkHostGamePending()
	return fn(_r)
end

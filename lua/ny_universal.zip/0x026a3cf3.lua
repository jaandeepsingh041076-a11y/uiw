local fn = _gn(0x2BB9620F)
function Global.GetWaterHeight(x, y, z, pheight)
	return fn(x, y, z, _fi(pheight) --[[ may be optional ]], _r)
end

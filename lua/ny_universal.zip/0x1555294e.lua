local fn = _gn(0x8bcf0014)
--- Disables the specified `rawKeyIndex`, making it not trigger the regular `IS_RAW_KEY_*` natives.
-- Virtual key codes can be found [here](https://learn.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes)
-- @param rawKeyIndex Index of raw key from keyboard.
-- @return Returns bool value of down state.
function Global.DisableRawKeyThisFrame(rawKeyIndex)
	return fn(rawKeyIndex, _r)
end

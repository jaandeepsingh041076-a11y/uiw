local fn = _gn(0x0B823C8D)
function Global.SetCarColourCombination(car, combination)
	return fn(car, combination)
end

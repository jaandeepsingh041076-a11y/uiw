local fn = _gn(0x69EC0E70)
function Global.ChangeBlipPriority(blip, priority)
	return fn(blip, priority)
end

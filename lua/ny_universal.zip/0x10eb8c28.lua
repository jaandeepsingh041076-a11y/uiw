local fn = _gn(0x29103E08)
function Global.TaskCower(ped)
	return fn(ped)
end

local fn = _gn(0x53456730)
function Global.DeleteHtmlScriptObject(htmlobj)
	return fn(htmlobj)
end

local fn = _gn(0x616F492C)
function Global.Printstring(value)
	return fn(_ts(value))
end

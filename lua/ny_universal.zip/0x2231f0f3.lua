local fn = _gn(0x05C619D7)
function Global.SetCharWantedByPolice(ped, wanted)
	return fn(ped, wanted)
end

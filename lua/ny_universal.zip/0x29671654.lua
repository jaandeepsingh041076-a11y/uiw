local fn = _gn(0x62E319C6)
function Global.GetPlayerId()
	return fn(_ri)
end

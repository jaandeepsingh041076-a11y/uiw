local fn = _gn(0x0C47057F)
function Global.PlayStreamFromPed(ped)
	return fn(ped)
end

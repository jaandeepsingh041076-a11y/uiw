local fn = _gn(0x178332FF)
function Global.TaskCarMissionPedTargetNotAgainstTraffic(ped, Unk152, Unk153, Unk154, Unk155, Unk156, Unk157, Unk158)
	return fn(ped, Unk152, Unk153, Unk154, Unk155, Unk156, Unk157, Unk158)
end

local fn = _gn(0x1B731C3F)
function Global.GetBlipInfoIdDisplay(blip)
	return fn(blip, _ri)
end

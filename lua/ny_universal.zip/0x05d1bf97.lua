local fn = _gn(0x755D6DF8)
function Global.GetPedObjectIsAttachedTo(obj)
	return fn(obj, _ri)
end

local fn = _gn(0x49261BA6)
function Global.Floor(value)
	return fn(value, _ri)
end

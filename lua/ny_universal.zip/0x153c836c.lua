local fn = _gn(0x8555dcba)
--- Clears the target list for the specified Mumble voice target ID.
-- @param targetId A Mumble voice target ID, ranging from 1..30 (inclusive).
function Global.MumbleClearVoiceTarget(targetId)
	return fn(targetId)
end

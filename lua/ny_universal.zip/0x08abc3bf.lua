local fn = _gn(0x2E291239)
function Global.IsCarUpsidedown(vehicle)
	return fn(vehicle, _r)
end

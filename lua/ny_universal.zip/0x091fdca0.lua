local fn = _gn(0x5384065B)
function Global.SetFadeInAfterLoad(set)
	return fn(set)
end

local fn = _gn(0x7F71342D)
function Global.DeleteCar(pVehicle)
	return fn(_ii(pVehicle) --[[ may be optional ]])
end

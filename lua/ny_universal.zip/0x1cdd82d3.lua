local fn = _gn(0x2DAE50C0)
function Global.SetDanceShakeInactiveImmediately()
	return fn()
end

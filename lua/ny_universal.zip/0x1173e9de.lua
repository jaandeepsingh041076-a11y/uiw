local fn = _gn(0x15285933)
function Global.CheckStuckTimer(car, timernum, timeout)
	return fn(car, timernum, timeout, _r)
end

local fn = _gn(0x53230256)
function Global.TaskShimmy(ped, Unk422)
	return fn(ped, Unk422)
end

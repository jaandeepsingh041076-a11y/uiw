local fn = _gn(0x79CF27AC)
function Global.SetTimeOneDayForward()
	return fn()
end

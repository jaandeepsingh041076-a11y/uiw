local fn = _gn(0x23B00129)
function Global.IsStreamingAdditionalText(textIndex)
	return fn(textIndex, _r)
end

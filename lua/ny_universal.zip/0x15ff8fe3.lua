local fn = _gn(0x03D16145)
function Global.IsCarModel(vehicle, model)
	return fn(vehicle, model, _r)
end

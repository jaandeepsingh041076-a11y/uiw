local fn = _gn(0x189E32C9)
function Global.CopySharedCharDecisionMaker(type, pDM)
	return fn(type, _ii(pDM) --[[ may be optional ]])
end

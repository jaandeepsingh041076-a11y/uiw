local fn = _gn(0x076863C9)
function Global.AddObjectToInteriorRoomByName(obj, room_name)
	return fn(obj, _ts(room_name))
end

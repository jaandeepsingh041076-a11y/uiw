local fn = _gn(0x295C4C52)
function Global.FreezeCarPosition(vehicle, frozen)
	return fn(vehicle, frozen)
end

local fn = _gn(0x10A1449C)
function Global.Atan2(Unk497, Unk498)
	return fn(Unk497, Unk498, _rf)
end

local fn = _gn(0x7B05072C)
function Global.GetBlipInfoIdObjectIndex(blip)
	return fn(blip, _ri)
end

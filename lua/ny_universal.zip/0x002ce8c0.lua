local fn = _gn(0x1D2F46AE)
function Global.SetObjectInvincible(obj, set)
	return fn(obj, set)
end

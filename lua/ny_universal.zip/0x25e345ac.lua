local fn = _gn(0x0F636C38)
function Global.GetPickupCoordinates(pickup)
	return fn(pickup, _f, _f, _f)
end

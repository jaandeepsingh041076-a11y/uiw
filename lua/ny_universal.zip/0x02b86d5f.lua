local fn = _gn(0x49FD2621)
function Global.ShutdownAndLaunchSinglePlayerGame()
	return fn()
end

local fn = _gn(0x103F14E4)
function Global.GetCharMeleeActionFlag0(ped)
	return fn(ped, _r)
end

local fn = _gn(0x44C27071)
function Global.RemoveTxd(txd)
	return fn(txd)
end

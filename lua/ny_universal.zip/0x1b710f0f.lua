local fn = _gn(0x135154B0)
function Global.HasNetworkPlayerLeftGame(playerIndex)
	return fn(playerIndex, _r)
end

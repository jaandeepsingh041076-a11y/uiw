local fn = _gn(0x37C85316)
function Global.IsThisPedAPlayer(ped)
	return fn(ped, _r)
end

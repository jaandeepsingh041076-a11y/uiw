local fn = _gn(0x051742D5)
function Global.SetMultiplayerHudCash(cash)
	return fn(cash)
end

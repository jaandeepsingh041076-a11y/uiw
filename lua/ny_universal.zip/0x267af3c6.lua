local fn = _gn(0x36F453FF)
function Global.GetNthClosestWaterNodeWithHeading(x, y, z, flag0, flag1)
	return fn(x, y, z, flag0, flag1, _v, _f, _r)
end

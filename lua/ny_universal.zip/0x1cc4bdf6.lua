local fn = _gn(0x4437501B)
function Global.TaskAimGunAtChar(ped, targetPed, duration)
	return fn(ped, targetPed, duration)
end

local fn = _gn(0x080F3B37)
function Global.IsPedDoingDriveby(ped)
	return fn(ped, _r)
end

local fn = _gn(0x4371559F)
function Global.SetClearHelpInMissionCleanup(set)
	return fn(set)
end

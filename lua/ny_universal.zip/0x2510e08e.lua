local fn = _gn(0x4A1D15D5)
function Global.SetUseHighdof(set)
	return fn(set)
end

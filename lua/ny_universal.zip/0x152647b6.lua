local fn = _gn(0x7DF26C8C)
function Global.GetCutsceneTime()
	return fn(_ri)
end

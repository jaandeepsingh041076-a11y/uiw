local fn = _gn(0x106811E4)
function Global.HasObjectCollidedWithAnything(obj)
	return fn(obj, _r)
end

local fn = _gn(0x7A93645C)
function Global.SetDoNotSpawnParkedCarsOnTop(pickup, set)
	return fn(pickup, set)
end

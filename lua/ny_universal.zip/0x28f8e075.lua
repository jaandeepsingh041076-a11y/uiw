local fn = _gn(0x0D6C0836)
function Global.CellCamIsCharVisible(ped)
	return fn(ped, _r)
end

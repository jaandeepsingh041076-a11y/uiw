local fn = _gn(0x736027E6)
function Global.CodeWantsMobilePhoneRemovedForWeaponSwitching()
	return fn(_r)
end

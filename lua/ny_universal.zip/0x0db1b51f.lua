local fn = _gn(0x31A219FA)
function Global.ObfuscateInt(Unk941, Unk942)
	return fn(Unk941, Unk942)
end

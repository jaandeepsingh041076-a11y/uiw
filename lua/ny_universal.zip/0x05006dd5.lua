local fn = _gn(0x5E486AA1)
function Global.IsPedFleeing(ped)
	return fn(ped, _r)
end

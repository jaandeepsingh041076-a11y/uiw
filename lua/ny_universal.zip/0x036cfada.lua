local fn = _gn(0x4ED45146)
function Global.SetCameraState(cam, state)
	return fn(cam, state)
end

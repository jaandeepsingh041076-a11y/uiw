local fn = _gn(0x5AF23F31)
function Global.SetCurrentMovie(filename)
	return fn(_ts(filename))
end

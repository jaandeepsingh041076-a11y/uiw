local fn = _gn(0x0C4B7DD3)
function Global.SetVehicleAlpha(veh, alpha)
	return fn(veh, alpha)
end

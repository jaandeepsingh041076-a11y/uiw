local fn = _gn(0x5D1C0A6A)
function Global.SecuromSpotCheck3()
	return fn(_r)
end

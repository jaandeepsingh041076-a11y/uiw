local fn = _gn(0x5C083072)
function Global.CloseGarage(garageName)
	return fn(_ts(garageName))
end

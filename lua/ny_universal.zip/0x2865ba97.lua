local fn = _gn(0x4A000F52)
function Global.IsCarStopped(vehicle)
	return fn(vehicle, _r)
end

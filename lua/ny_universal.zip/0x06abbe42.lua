local fn = _gn(0x4D2771CE)
function Global.ConvertMetresToFeet(metres)
	return fn(metres, _rf)
end

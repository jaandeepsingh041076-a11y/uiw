local fn = _gn(0x417F6EBD)
function Global.TaskUseMobilePhone(ped, use)
	return fn(ped, use)
end

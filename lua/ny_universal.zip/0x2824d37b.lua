local fn = _gn(0x575E2880)
function Global.SetCharHealth(ped, health)
	return fn(ped, health)
end

local fn = _gn(0x50424095)
function Global.GetNetworkIdFromObject(obj, netid)
	return fn(obj, _ii(netid) --[[ may be optional ]])
end

local fn = _gn(0x1CB2670D)
function Global.TaskSetCharDecisionMaker(ped, dm)
	return fn(ped, dm)
end

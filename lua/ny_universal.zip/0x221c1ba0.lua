local fn = _gn(0x6D0E1BCE)
function Global.LocateCharAnyMeansObject_3d(ped, obj, x, y, z, flag)
	return fn(ped, obj, x, y, z, flag, _r)
end

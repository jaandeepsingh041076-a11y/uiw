local fn = _gn(0x3D385F6D)
function Global.DoesGroupExist(group)
	return fn(group, _r)
end

local fn = _gn(0x0DDD70AE)
function Global.CreateMissionTrain(unknown1, x, y, z, unknown2, pTrain)
	return fn(unknown1, x, y, z, unknown2, _ii(pTrain) --[[ may be optional ]])
end

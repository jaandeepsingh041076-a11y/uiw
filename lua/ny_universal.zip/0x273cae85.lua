local fn = _gn(0x5DDB09F8)
function Global.IsCharRespondingToAnyEvent(ped)
	return fn(ped, _r)
end

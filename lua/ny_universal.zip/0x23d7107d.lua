local fn = _gn(0x9a3144bc)
--- **Experimental**: This native may be altered or removed in future versions of CitizenFX without warning.
-- Returns the memory address of an entity.
-- This native is intended for singleplayer debugging, and may not be available during multiplayer.
-- @param entity The handle of the entity to get the address of.
-- @return A pointer containing the memory address of the entity.
function Global.GetEntityAddress(entity)
	return fn(entity, _rl)
end

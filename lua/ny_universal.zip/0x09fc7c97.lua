local fn = _gn(0x32D3165D)
function Global.ForceInitialPlayerStation(stationName)
	return fn(_ts(stationName))
end

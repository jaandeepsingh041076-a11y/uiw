local fn = _gn(0x69F55DCC)
function Global.DontSuppressAnyCarModels()
	return fn()
end

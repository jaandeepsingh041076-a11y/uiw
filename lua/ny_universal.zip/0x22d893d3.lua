local fn = _gn(0x30B1316B)
function Global.GetBlipSprite(blip)
	return fn(blip, _ri)
end

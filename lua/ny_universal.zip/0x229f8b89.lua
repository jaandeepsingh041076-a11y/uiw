local fn = _gn(0x524F7543)
function Global.NetworkGetMaxSlots()
	return fn(_ri)
end

local fn = _gn(0x00C87FB8)
function Global.GetCinematicCam(cam)
	return fn(_ii(cam) --[[ may be optional ]])
end

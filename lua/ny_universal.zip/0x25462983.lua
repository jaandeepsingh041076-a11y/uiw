local fn = _gn(0x69A52C96)
function Global.GetCharWillCowerInsteadOfFleeing(ped)
	return fn(ped, _r)
end

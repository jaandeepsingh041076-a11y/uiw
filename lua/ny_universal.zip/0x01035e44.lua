local fn = _gn(0x09FD24F3)
function Global.GetWebPageHeight(htmlviewport)
	return fn(htmlviewport, _rf)
end

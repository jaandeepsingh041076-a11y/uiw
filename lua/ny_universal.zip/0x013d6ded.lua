local fn = _gn(0x58FB0BC1)
function Global.SetCharWillCowerInsteadOfFleeing(ped, set)
	return fn(ped, set)
end

local fn = _gn(0x26810BE3)
function Global.DrawCheckpointWithAlpha(x, y, z, radius, r, g, b, a)
	return fn(x, y, z, radius, r, g, b, a)
end

local fn = _gn(0x42690F6B)
function Global.SetSniperZoomFactor(factor)
	return fn(factor)
end

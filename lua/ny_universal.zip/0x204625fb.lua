local fn = _gn(0x7E657B56)
function Global.EnableMaxAmmoCap(enable)
	return fn(enable)
end

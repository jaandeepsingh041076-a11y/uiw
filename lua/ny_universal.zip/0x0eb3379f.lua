local fn = _gn(0x6F2A5430)
function Global.NetworkShowPlayerProfileUi(playerIndex)
	return fn(playerIndex)
end

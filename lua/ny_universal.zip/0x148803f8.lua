local fn = _gn(0x208C03C9)
function Global.EnableSaveHouse(savehouse, enable)
	return fn(savehouse, enable)
end

local fn = _gn(0x5F3B6079)
function Global.AlterWantedLevelNoDrop(playerIndex, level)
	return fn(playerIndex, level)
end

local fn = _gn(0x6A9E5CE5)
function Global.GetBlipInfoIdType(blip)
	return fn(blip, _ri)
end

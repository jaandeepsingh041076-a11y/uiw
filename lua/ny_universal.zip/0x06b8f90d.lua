local fn = _gn(0x2F1D6843)
function Global.CreateCar(nameHash, x, y, z, unknownTrue)
	return fn(nameHash, x, y, z, _i, unknownTrue)
end

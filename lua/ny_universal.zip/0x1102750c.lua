local fn = _gn(0x678813A4)
function Global.GetCurrentPlaybackNumberForCar(car)
	return fn(car, _ri)
end

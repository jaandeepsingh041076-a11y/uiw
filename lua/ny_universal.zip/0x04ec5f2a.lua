local fn = _gn(0x57895F38)
function Global.HasObjectBeenPhotographed(obj)
	return fn(obj, _r)
end

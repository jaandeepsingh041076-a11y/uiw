local fn = _gn(0x1EAD1D7D)
function Global.SetPedDontDoEvasiveDives(ped, value)
	return fn(ped, value)
end

local fn = _gn(0x4727446B)
function Global.SetCarCanBeVisiblyDamaged(vehicle, value)
	return fn(vehicle, value)
end

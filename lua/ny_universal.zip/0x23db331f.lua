local fn = _gn(0x75E005F1)
function Global.GetRootCam(rootcam)
	return fn(_ii(rootcam) --[[ may be optional ]])
end

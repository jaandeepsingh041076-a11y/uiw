local fn = _gn(0x7E7E4879)
function Global.SetMobilePhoneRotation(x, y, z)
	return fn(x, y, z)
end

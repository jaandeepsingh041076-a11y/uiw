local fn = _gn(0x011D360D)
function Global.TaskShuffleToNextCarSeat(ped, Unk428)
	return fn(ped, Unk428)
end

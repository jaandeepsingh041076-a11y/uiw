local fn = _gn(0x3C3E5FA0)
function Global.LocateCharOnFootCar_3d(ped, car, x, y, z, flag)
	return fn(ped, car, x, y, z, flag, _r)
end

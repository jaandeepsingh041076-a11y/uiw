local fn = _gn(0x440D0A91)
function Global.SetCharOnlyDamagedByPlayer(ped, set)
	return fn(ped, set)
end

local fn = _gn(0x775F6665)
function Global.IsPlaceCarBombActive()
	return fn(_r)
end

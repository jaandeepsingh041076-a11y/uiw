local fn = _gn(0x49EA22C8)
function Global.SetVehInteriorlight(veh, set)
	return fn(veh, set)
end

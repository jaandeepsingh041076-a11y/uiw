local fn = _gn(0x590A6F04)
function Global.Asin(value)
	return fn(value, _rf)
end

local fn = _gn(0x64655F10)
function Global.IsMouseUsingVerticalInversion()
	return fn(_r)
end

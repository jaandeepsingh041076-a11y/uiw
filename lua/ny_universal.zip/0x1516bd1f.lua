local fn = _gn(0x54AF2F7A)
function Global.SetCharForceDieInCar(ped, set)
	return fn(ped, set)
end

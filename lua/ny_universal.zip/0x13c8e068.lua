local fn = _gn(0x6FFE0DFD)
function Global.RequestScript(scriptName)
	return fn(_ts(scriptName))
end

local fn = _gn(0x71755E9B)
function Global.GetMaxWantedLevel(pMaxWantedLevel)
	return fn(_ii(pMaxWantedLevel) --[[ may be optional ]])
end

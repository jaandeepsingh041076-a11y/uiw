local fn = _gn(0x67A42263)
function Global.DoesVehicleExist(vehicle)
	return fn(vehicle, _r)
end

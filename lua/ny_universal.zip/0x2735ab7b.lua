local fn = _gn(0x7330132C)
function Global.RemoveProjtexFromObject(obj)
	return fn(obj)
end

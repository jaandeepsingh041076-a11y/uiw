local fn = _gn(0x0E3B49BF)
function Global.DeleteChar(pPed)
	return fn(_ii(pPed) --[[ may be optional ]])
end

local fn = _gn(0x7B8D68E7)
function Global.SetRoute(blip, value)
	return fn(blip, value)
end

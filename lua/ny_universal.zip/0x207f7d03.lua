local fn = _gn(0x5996315E)
function Global.ConvertIntToPlayerindex(playerId)
	return fn(playerId, _ri)
end

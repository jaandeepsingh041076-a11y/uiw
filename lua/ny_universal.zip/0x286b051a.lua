local fn = _gn(0x309C265B)
function Global.IsCharSittingInCar(ped, vehicle)
	return fn(ped, vehicle, _r)
end

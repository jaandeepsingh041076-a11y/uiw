local fn = _gn(0x176C2DB5)
function Global.HasControlOfNetworkId(netid)
	return fn(netid, _r)
end

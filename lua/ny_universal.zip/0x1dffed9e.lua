local fn = _gn(0x78CE659D)
function Global.ResetCarWheels(car, reset)
	return fn(car, reset)
end

local fn = _gn(0x7B4A7CD6)
function Global.SetVehicleExplodesOnHighExplosionDamage(veh, set)
	return fn(veh, set)
end

local fn = _gn(0x3E441A58)
function Global.LocateCharAnyMeansChar_3d(ped, pednext, x, y, z, flag)
	return fn(ped, pednext, x, y, z, flag, _r)
end

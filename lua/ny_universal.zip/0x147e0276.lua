local fn = _gn(0x7DA4736D)
function Global.IsWantedLevelGreater(playerIndex, level)
	return fn(playerIndex, level, _r)
end

local fn = _gn(0x76181322)
function Global.Ceil(value)
	return fn(value, _ri)
end

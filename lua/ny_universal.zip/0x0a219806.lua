local fn = _gn(0x3AB06137)
function Global.IsCharTouchingObject(ped, obj)
	return fn(ped, obj, _r)
end

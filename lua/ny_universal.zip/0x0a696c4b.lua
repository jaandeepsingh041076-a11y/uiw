local fn = _gn(0x6E4E1BEC)
function Global.IsHelpMessageBeingDisplayed()
	return fn(_r)
end

local fn = _gn(0x441B1EAF)
function Global.SetCharWeaponSkill(ped, skill)
	return fn(ped, skill)
end

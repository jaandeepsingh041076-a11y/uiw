local fn = _gn(0x259E305F)
function Global.ToFloat(value)
	return fn(value, _rf)
end

local fn = _gn(0x43EF56EE)
function Global.SetSuppressHeadlightSwitch(set)
	return fn(set)
end

local fn = _gn(0x059901B9)
function Global.SetEveryoneIgnorePlayer(playerIndex, value)
	return fn(playerIndex, value)
end

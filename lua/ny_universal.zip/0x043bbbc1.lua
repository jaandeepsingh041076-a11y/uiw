local fn = _gn(0x08181609)
function Global.NetworkStoreSinglePlayerGame()
	return fn(_ri)
end

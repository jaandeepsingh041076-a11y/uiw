local fn = _gn(0x6ED17CF8)
function Global.GetRandomCharInAreaOffsetNoSave(x, y, z, sx, sy, sz, pPed)
	return fn(x, y, z, sx, sy, sz, _ii(pPed) --[[ may be optional ]])
end

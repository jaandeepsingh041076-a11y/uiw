local fn = _gn(0x3D703ED7)
function Global.StartCarFire(vehicle)
	return fn(vehicle, _ri)
end

local fn = _gn(0x67DB4150)
function Global.GetGroupFormationSpacing(group, spacing)
	return fn(group, _fi(spacing) --[[ may be optional ]])
end

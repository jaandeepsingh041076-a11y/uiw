local fn = _gn(0x1E87298A)
function Global.DisplayAreaName(display)
	return fn(display)
end

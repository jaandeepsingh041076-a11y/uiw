local fn = _gn(0x4371502A)
function Global.RemoveCoverPoint(coverPoint)
	return fn(coverPoint)
end

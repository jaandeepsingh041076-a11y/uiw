local fn = _gn(0x06C71148)
function Global.SetWidescreenBorders(set)
	return fn(set)
end

local fn = _gn(0x66317064)
function Global.SaveFloatToDebugFile(Unk1117)
	return fn(Unk1117)
end

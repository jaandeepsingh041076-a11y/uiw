local fn = _gn(0x046A4720)
function Global.IsCharArmed(ped, slot)
	return fn(ped, slot, _r)
end

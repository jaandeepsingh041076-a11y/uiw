local fn = _gn(0x2C1B52CE)
function Global.AddBlipForGangTerritory(x0, y0, x1, y1, colour, blip)
	return fn(x0, y0, x1, y1, colour, _ii(blip) --[[ may be optional ]])
end

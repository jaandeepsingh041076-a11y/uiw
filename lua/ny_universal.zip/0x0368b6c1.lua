local fn = _gn(0x361A01AD)
function Global.UnpausePlaybackRecordedCar(car)
	return fn(car)
end

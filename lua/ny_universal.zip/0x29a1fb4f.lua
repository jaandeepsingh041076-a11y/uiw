local fn = _gn(0x5FFE33EC)
function Global.SetVehAlarmDuration(veh, duration)
	return fn(veh, duration)
end

local fn = _gn(0x69A72C50)
function Global.AllowEmergencyServices(allow)
	return fn(allow)
end

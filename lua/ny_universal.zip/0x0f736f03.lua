local fn = _gn(0x45DF1D92)
function Global.ForceInteriorLightingForPlayer(player, force)
	return fn(player, force)
end

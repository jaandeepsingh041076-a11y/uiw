local fn = _gn(0x45D71590)
function Global.SetObjectLights(obj, lights)
	return fn(obj, lights)
end

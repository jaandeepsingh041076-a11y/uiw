local fn = _gn(0x720673D9)
function Global.SetVehicleIsConsideredByPlayer(veh, set)
	return fn(veh, set)
end

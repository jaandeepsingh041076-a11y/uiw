local fn = _gn(0x0E635761)
function Global.IsControlPressed(Unk823, controlid)
	return fn(Unk823, controlid, _r)
end

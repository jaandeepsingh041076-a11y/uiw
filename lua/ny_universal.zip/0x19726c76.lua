local fn = _gn(0x4E61480A)
function Global.HasModelLoaded(model)
	return fn(model, _r)
end

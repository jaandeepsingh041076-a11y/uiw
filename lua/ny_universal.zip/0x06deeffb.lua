local fn = _gn(0x298827FC)
function Global.SetCamNearClip(cam, clip)
	return fn(cam, clip)
end

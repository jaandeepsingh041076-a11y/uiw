local fn = _gn(0x662235A5)
function Global.SetCharAllowedToRunOnBoats(ped, set)
	return fn(ped, set)
end

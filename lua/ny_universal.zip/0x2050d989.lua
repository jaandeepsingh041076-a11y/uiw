local fn = _gn(0xe5e9ebbb)
--- Returns the name of the currently executing resource.
-- @return The name of the resource.
function Global.GetCurrentResourceName()
	return fn(_s)
end

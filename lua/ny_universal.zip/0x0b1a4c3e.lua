local fn = _gn(0x05D70FE8)
function Global.SetRichPresenceTemplatemp6(Unk989, Unk990, Unk991)
	return fn(Unk989, Unk990, Unk991)
end

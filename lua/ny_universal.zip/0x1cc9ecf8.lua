local fn = _gn(0x3CD60F11)
function Global.PlayMovie()
	return fn()
end

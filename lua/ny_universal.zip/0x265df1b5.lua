local fn = _gn(0x314E106A)
function Global.NetworkGetNextTextChat()
	return fn(_s)
end

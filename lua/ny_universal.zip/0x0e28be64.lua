local fn = _gn(0x60F720F6)
function Global.GetVehicleTypeOfModel(model)
	return fn(model, _ri)
end

local fn = _gn(0x7F4C0E47)
function Global.AsciiIntToString(ascii)
	return fn(ascii, _s)
end

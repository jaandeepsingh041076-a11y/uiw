local fn = _gn(0x7EDD58E1)
function Global.AttachParachuteModelToPlayer(ped, obj)
	return fn(ped, obj)
end

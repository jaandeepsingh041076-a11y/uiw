local fn = _gn(0x59AA0635)
function Global.NetworkGetHostMatchProgress(host)
	return fn(host, _ri)
end

local fn = _gn(0x6A660231)
function Global.ReportSuspectDown()
	return fn()
end

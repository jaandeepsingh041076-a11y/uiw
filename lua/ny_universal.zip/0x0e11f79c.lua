local fn = _gn(0x05766DDE)
function Global.ChangePickupBlipSprite(sprite)
	return fn(sprite)
end

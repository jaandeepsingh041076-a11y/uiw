local fn = _gn(0x362B5D1B)
function Global.AllowLockonToFriendlyPlayers(player, allow)
	return fn(player, allow)
end

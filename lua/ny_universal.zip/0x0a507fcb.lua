local fn = _gn(0x763274B7)
function Global.PlaySoundFromVehicle(SoundId, SoundName, veh)
	return fn(SoundId, _ts(SoundName), veh)
end

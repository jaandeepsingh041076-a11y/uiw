local fn = _gn(0x79700852)
function Global.SetPedExistsOnAllMachines(ped, exists)
	return fn(ped, exists)
end

local fn = _gn(0x17BC668D)
function Global.IsVehDriveable(vehicle)
	return fn(vehicle, _r)
end

local fn = _gn(0x51F54148)
function Global.SetDecisionMakerAttributeCanChangeTarget(dm, value)
	return fn(dm, value)
end

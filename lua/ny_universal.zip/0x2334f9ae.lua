local fn = _gn(0x72AE63C8)
function Global.TaskSwapWeapon(ped, weapon)
	return fn(ped, weapon)
end

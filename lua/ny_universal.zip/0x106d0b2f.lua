local fn = _gn(0x2F542797)
function Global.NetworkSetTalkerProximity(Unk933)
	return fn(Unk933)
end

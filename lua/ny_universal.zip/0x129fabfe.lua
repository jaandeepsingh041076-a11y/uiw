local fn = _gn(0x3CAA1340)
function Global.NetworkDidInviteFriend(FRIENDNAME)
	return fn(_ts(FRIENDNAME), _r)
end

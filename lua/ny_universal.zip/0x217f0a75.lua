local fn = _gn(0x0AB9317B)
function Global.ClearCharLastDamageEntity(ped)
	return fn(ped)
end

local fn = _gn(0x03622640)
function Global.RemoveAllPickupsOfType(type)
	return fn(type)
end

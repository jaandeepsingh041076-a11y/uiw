local fn = _gn(0x204A6AA4)
function Global.SetTextCentre(value)
	return fn(value)
end

local fn = _gn(0x07244253)
function Global.ClearHelp()
	return fn()
end

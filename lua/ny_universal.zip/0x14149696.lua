local fn = _gn(0x3B4F1EBA)
function Global.AddCamSplineNode(cam, camnode)
	return fn(cam, camnode)
end

local fn = _gn(0x7E3D3430)
function Global.SetDoorState(door, flag, Unk95)
	return fn(door, flag, Unk95)
end

local fn = _gn(0x8839120d)
--- FIND_NEXT_VEHICLE
function Global.FindNextVehicle(findHandle, outEntity)
	return fn(findHandle, _ii(outEntity) --[[ may be optional ]], _r)
end

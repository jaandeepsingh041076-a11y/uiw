local fn = _gn(0x0FFD1A92)
function Global.SwitchRandomTrains(on)
	return fn(on)
end

local fn = _gn(0x38905687)
function Global.GetStatFrontendVisibility(stat)
	return fn(stat, _r)
end

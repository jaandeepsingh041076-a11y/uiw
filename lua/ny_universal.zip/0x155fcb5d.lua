local fn = _gn(0x60EC0540)
function Global.SetCharAsMissionChar(ped)
	return fn(ped)
end

local fn = _gn(0x0F9B3A1C)
function Global.PlaystatsCheat(stat)
	return fn(stat)
end

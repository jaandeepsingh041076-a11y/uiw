local fn = _gn(0x79A95BF9)
function Global.IsPlayerBeingArrested()
	return fn(_r)
end

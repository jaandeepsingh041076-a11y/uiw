local fn = _gn(0x686B6395)
function Global.SetCamShake(cam, Unk572, shakeval)
	return fn(cam, Unk572, shakeval)
end

local fn = _gn(0x4F705478)
function Global.SetUseLegIk(player, set)
	return fn(player, set)
end

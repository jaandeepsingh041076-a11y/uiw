local fn = _gn(0x4F9342F3)
function Global.GetCreateRandomCops()
	return fn(_r)
end

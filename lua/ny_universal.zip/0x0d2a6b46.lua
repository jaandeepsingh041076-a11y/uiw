local fn = _gn(0x137C35BA)
function Global.SetCarProofs(vehicle, bulletProof, fireProof, explosionProof, collisionProof, meleeProof)
	return fn(vehicle, bulletProof, fireProof, explosionProof, collisionProof, meleeProof)
end

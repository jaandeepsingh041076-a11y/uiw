local fn = _gn(0x3E8443E0)
function Global.WasPedSkeletonUpdated(ped)
	return fn(ped, _r)
end

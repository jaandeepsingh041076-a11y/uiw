local fn = _gn(0x4ECE1AD2)
function Global.HasCutsceneFinished()
	return fn(_r)
end

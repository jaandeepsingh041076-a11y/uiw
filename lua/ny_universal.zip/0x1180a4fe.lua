local fn = _gn(0x5F8C3937)
function Global.GetTotalDurationOfCarRecording(CarRec)
	return fn(CarRec, _rf)
end

local fn = _gn(0x617B191D)
function Global.InitFrontendHelperText()
	return fn()
end

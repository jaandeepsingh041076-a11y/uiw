local fn = _gn(0x50DC54B3)
function Global.IsSniperInverted()
	return fn(_r)
end

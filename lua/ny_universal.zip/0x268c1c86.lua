local fn = _gn(0x12AA6D71)
function Global.StoreWantedLevel(playerIndex, value)
	return fn(playerIndex, _ii(value) --[[ may be optional ]])
end

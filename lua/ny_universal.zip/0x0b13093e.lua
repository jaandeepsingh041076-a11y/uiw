local fn = _gn(0x5C8C2E39)
function Global.IsCharGettingInToACar(ped)
	return fn(ped, _r)
end

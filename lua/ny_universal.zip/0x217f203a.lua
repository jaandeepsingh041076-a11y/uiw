local fn = _gn(0x08AB2787)
function Global.SetAllowDummyConversions(set)
	return fn(set)
end

local fn = _gn(0x5FDF1493)
function Global.SetCollideWithPeds(set)
	return fn(set)
end

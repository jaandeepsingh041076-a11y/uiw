local fn = _gn(0x711214F3)
function Global.DisablePlayerLockon(playerIndex, disabled)
	return fn(playerIndex, disabled)
end

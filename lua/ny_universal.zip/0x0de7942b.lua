local fn = _gn(0x6ED83424)
function Global.CancelOverrideRestart()
	return fn()
end

local fn = _gn(0x38293796)
function Global.MakePlayerFireProof(player, proof)
	return fn(player, proof)
end

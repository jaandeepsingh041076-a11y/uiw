local fn = _gn(0x04C65BEB)
function Global.GetCutsceneSectionPlaying()
	return fn(_ri)
end

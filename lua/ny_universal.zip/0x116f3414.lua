local fn = _gn(0x43E42686)
function Global.SetCamActive(camera, value)
	return fn(camera, value)
end

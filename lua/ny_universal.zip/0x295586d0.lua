local fn = _gn(0x7CAE2557)
function Global.SetDecisionMakerAttributeTargetInjuredReaction(dm, value)
	return fn(dm, value)
end

local fn = _gn(0x08D85CBB)
function Global.ClearThisPrint(gxtentry)
	return fn(_ts(gxtentry))
end

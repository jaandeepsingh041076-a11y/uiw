local fn = _gn(0x52632919)
function Global.DisplayHud(display)
	return fn(display)
end

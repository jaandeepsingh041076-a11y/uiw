local fn = _gn(0x5D975A46)
function Global.CamSequenceClose()
	return fn()
end

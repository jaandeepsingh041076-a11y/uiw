local fn = _gn(0x7E8E06F8)
function Global.IsPcUsingJoypad()
	return fn(_r)
end

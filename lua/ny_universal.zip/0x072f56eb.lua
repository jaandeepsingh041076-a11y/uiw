local fn = _gn(0x32A3647C)
function Global.GetTextInputActive()
	return fn(_r)
end

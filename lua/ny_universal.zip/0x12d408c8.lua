local fn = _gn(0x3F9B2DD6)
function Global.SetTextViewportId(id)
	return fn(id)
end

local fn = _gn(0x5BE115FD)
function Global.AddPointToGpsRaceTrack(point)
	return fn(_v)
end

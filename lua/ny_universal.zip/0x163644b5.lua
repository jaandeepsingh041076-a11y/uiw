local fn = _gn(0x7CA8382B)
function Global.FreezeObjectPosition(obj, frozen)
	return fn(obj, frozen)
end

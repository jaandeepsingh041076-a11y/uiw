local fn = _gn(0x38d19210)
--- This native is not implemented.
function Global.ExperimentalSaveCloneSync(entity)
	return fn(entity, _s)
end

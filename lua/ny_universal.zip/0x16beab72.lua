local fn = _gn(0x5AA1795C)
function Global.SetPedAlpha(ped, alpha)
	return fn(ped, alpha)
end

local fn = _gn(0x3BF93ED7)
function Global.SetPedDiesWhenInjured(ped, value)
	return fn(ped, value)
end

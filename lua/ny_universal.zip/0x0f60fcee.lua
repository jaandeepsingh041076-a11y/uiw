local fn = _gn(0x1D8800E3)
function Global.ChangeBlipColour(blip, colour)
	return fn(blip, colour)
end

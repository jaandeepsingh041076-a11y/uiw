local fn = _gn(0x1F913BC7)
function Global.GetCarDeformationAtPos(vehicle, x, y, z, pDeformation)
	return fn(vehicle, x, y, z, _v)
end

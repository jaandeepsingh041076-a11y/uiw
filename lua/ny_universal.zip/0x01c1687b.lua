local fn = _gn(0x4678769C)
function Global.TaskClimb(ped, Unk185)
	return fn(ped, Unk185)
end

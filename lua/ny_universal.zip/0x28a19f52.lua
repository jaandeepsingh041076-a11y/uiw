local fn = _gn(0x7781290F)
function Global.SwitchCarSiren(car, siren)
	return fn(car, siren)
end

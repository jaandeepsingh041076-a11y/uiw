local fn = _gn(0x60AD2FE0)
function Global.SetCamNearDof(cam, dof)
	return fn(cam, dof)
end

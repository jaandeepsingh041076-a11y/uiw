local fn = _gn(0x1FC96A99)
function Global.SetEnableRcDetonate(set)
	return fn(set)
end

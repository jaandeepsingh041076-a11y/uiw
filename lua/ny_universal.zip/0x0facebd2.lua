local fn = _gn(0x4B2625BE)
function Global.ChangeBlipTeamRelevance(blip, relevance)
	return fn(blip, relevance)
end

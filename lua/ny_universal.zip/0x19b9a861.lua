local fn = _gn(0x08240FB7)
function Global.SetRenderTrainAsDerailed(train, set)
	return fn(train, set)
end

local fn = _gn(0x530F4572)
function Global.GetAcceptButton()
	return fn(_ri)
end

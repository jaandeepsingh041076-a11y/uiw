local fn = _gn(0x2B670CD0)
function Global.PlayerHasGreyedOutStars(playerIndex)
	return fn(playerIndex, _r)
end

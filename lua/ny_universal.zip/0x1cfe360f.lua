local fn = _gn(0x10436A86)
function Global.SetStatFrontendDisplayType(stat, type)
	return fn(stat, type)
end

local fn = _gn(0x599E4FA1F87EB5FF)
function Global.NetworkGetRandomInt()
	return fn(_ri)
end

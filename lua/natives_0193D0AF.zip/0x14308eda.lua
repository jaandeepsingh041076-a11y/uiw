local fn = _gn(0x6889498B3E19C797)
function Global.ArrayValueAddObject(arrayData)
	return fn(_ii(arrayData) --[[ may be optional ]], _rl)
end

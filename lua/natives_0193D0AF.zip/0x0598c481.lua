local fn = _gn(0x22EF8FF8778030EB)
function Global.ResetPedInVehicleContext(ped)
	return fn(ped)
end

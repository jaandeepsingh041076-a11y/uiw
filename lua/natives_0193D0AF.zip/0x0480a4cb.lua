local fn = _gn(0xF3A21BCD95725A4A)
function Global.IsControlPressed(inputGroup, control)
	return fn(inputGroup, control, _r)
end

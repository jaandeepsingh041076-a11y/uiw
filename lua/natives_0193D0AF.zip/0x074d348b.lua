local fn = _gn(0x07E5B515DB0636FC)
function Global.RenderScriptCams(render, ease, easeTime, p3, p4)
	return fn(render, ease, easeTime, p3, p4)
end

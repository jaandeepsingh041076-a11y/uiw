local fn = _gn(0x8421EB4DA7E391B9)
function Global.SetPedPreferredCoverSet(ped, itemSet)
	return fn(ped, itemSet)
end

local fn = _gn(0xE65F427EB70AB1ED)
function Global.PlaySoundFromEntity(soundId, audioName, entity, audioRef, p4, p5)
	return fn(soundId, _ts(audioName), entity, _ts(audioRef), p4, p5)
end

local fn = _gn(0x67AA4D73F0CFA86B)
function Global.EnableScriptBrainSet(brainSet)
	return fn(brainSet)
end

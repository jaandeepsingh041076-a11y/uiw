local fn = _gn(0x291E373D483E7EE7)
function Global.AnyPassengersRappeling(vehicle)
	return fn(vehicle, _r)
end

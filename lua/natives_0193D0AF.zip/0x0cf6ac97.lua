local fn = _gn(0x428BACCDF5E26EAD)
function Global.N_0x428baccdf5e26ead(vehicle, p1)
	return fn(vehicle, p1)
end

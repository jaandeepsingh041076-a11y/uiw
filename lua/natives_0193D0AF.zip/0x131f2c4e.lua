local fn = _gn(0xAEEDAD1420C65CC0)
function Global.SetForcePedFootstepsTracks(toggle)
	return fn(toggle)
end

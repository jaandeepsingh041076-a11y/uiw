local fn = _gn(0x499EF20C5DB25C59)
function Global.DoesCutsceneEntityExist(cutsceneEntName, modelHash)
	return fn(_ts(cutsceneEntName), _ch(modelHash), _r)
end

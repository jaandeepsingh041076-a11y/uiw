local fn = _gn(0x9C00E77AF14B2DFF)
function Global.TaskGetOffBoat(ped, boat)
	return fn(ped, boat)
end

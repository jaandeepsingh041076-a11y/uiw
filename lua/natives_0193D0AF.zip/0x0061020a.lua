local fn = _gn(0xFE54B92A344583CA)
function Global.SetTowTruckCraneHeight(towTruck, height)
	return fn(towTruck, height)
end

local fn = _gn(0x09693B0312F91649)
function Global.TaskRappelFromHeli(ped, unused)
	return fn(ped, unused)
end

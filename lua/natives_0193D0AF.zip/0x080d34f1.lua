local fn = _gn(0xDDF803377F94AAA8)
function Global.SetPedGestureGroup(ped, animGroupGesture)
	return fn(ped, _ts(animGroupGesture))
end

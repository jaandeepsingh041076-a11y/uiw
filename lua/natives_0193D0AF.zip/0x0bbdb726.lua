local fn = _gn(0x694E00132F2823ED)
function Global.N_0x694e00132f2823ed(entity, p1)
	return fn(entity, p1)
end

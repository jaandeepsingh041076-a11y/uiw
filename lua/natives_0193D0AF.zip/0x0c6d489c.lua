local fn = _gn(0x129466ED55140F8D)
function Global.N_0x129466ed55140f8d(ped, toggle)
	return fn(ped, toggle)
end

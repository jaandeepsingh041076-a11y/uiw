local fn = _gn(0x726256CC1EEB182F)
function Global.ClearFacialIdleAnimOverride(ped)
	return fn(ped)
end

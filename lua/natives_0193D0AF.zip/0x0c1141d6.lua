local fn = _gn(0x05A42BA9FC8DA96B)
function Global.GetNameOfThread(threadId)
	return fn(threadId, _s)
end

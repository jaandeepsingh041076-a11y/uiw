local fn = _gn(0xB85F26619073E775)
function Global.SetHdArea(x, y, z, ground)
	return fn(x, y, z, ground)
end

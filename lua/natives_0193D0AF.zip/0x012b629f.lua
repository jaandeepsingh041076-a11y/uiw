local fn = _gn(0x52923C4710DD9907)
function Global.ForceRoomForEntity(entity, interiorID, roomHashKey)
	return fn(entity, interiorID, _ch(roomHashKey))
end

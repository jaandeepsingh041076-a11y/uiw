local fn = _gn(0x27F9D613092159CF)
function Global.RemoveAllPickupsOfType(pickupHash)
	return fn(_ch(pickupHash))
end

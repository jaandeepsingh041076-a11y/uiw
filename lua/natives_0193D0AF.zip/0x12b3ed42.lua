local fn = _gn(0x8844BBFCE30AA9E9)
function Global.ClearPedAlternateWalkAnim(ped, p1)
	return fn(ped, p1)
end

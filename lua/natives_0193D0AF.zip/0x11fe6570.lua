local fn = _gn(0x5354C5BA2EA868A4)
function Global.SetMapFullScreen(toggle)
	return fn(toggle)
end

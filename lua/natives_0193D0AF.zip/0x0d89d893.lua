local fn = _gn(0xC2B82527CA77053E)
function Global.NetworkClearPropertyId()
	return fn()
end

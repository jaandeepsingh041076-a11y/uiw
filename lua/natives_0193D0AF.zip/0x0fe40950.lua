local fn = _gn(0x817268968605947A)
function Global.AssistedMovementRequestRoute(route)
	return fn(_ts(route))
end

local fn = _gn(0xE7FFAE5EBF23D890)
function Global.DrawSprite(textureDict, textureName, screenX, screenY, width, height, heading, red, green, blue, alpha)
	return fn(_ts(textureDict), _ts(textureName), screenX, screenY, width, height, heading, red, green, blue, alpha)
end

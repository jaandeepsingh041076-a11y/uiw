local fn = _gn(0xACFB2463CC22BED2)
function Global.SetLastDrivenVehicle(vehicle)
	return fn(vehicle)
end

local fn = _gn(0x8609C75EC438FB3B)
function Global.AddCamSplineNode(camera, x, y, z, xRot, yRot, zRot, length, p8, p9)
	return fn(camera, x, y, z, xRot, yRot, zRot, length, p8, p9)
end

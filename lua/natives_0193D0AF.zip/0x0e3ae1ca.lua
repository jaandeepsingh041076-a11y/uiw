local fn = _gn(0x23D69E0465570028)
function Global.BeginTextCommandObjective(p0)
	return fn(_ts(p0))
end

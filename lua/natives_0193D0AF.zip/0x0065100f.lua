local fn = _gn(0x23DFB504655D0CE4)
function Global.NetworkSessionWasInvited()
	return fn(_r)
end

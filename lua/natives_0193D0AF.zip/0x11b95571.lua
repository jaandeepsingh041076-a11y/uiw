local fn = _gn(0xEA241BB04110F091)
function Global.SetPlayerAngry(playerPed, disabled)
	return fn(playerPed, disabled)
end

local fn = _gn(0x8E02D73914064223)
function Global.NetworkAddFriend(p1)
	return fn(_i, _ts(p1), _r)
end

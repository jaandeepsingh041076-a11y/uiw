local fn = _gn(0x99C82F8A139F3E4E)
function Global.SetVehicleHudSpecialAbilityBarActive(vehicle, p1)
	return fn(vehicle, p1)
end

local fn = _gn(0x8B6A4DD0AF9CE215)
function Global.NetworkSessionSetMaxPlayers(playerType, playerCount)
	return fn(playerType, playerCount)
end

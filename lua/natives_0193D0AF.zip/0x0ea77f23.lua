local fn = _gn(0xF51D36185993515D)
function Global.N_0xf51d36185993515d(checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
	return fn(checkpoint, posX, posY, posZ, unkX, unkY, unkZ)
end

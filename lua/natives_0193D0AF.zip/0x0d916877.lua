local fn = _gn(0xBC1D768F2F5D6C05)
function Global.NetworkHashFromPlayerHandle(player)
	return fn(player, _ri)
end

local fn = _gn(0x8132C0EB8B2B3293)
function Global.HasBgScriptBeenDownloaded()
	return fn(_r)
end

local fn = _gn(0x2F794A877ADD4C92)
function Global.StopAllAlarms(stop)
	return fn(stop)
end

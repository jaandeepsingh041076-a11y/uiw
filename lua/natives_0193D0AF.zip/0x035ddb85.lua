local fn = _gn(0x6ACF6B7225801CD7)
function Global.SetSynchronizedSceneOrigin(sceneID, x, y, z, roll, pitch, yaw, p7)
	return fn(sceneID, x, y, z, roll, pitch, yaw, p7)
end

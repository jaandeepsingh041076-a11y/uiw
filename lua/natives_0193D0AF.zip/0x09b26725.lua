local fn = _gn(0x560A43136EB58105)
function Global.SetPedHelmet(ped, canWearHelmet)
	return fn(ped, canWearHelmet)
end

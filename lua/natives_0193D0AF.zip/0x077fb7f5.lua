local fn = _gn(0x85796B0549DDE156)
function Global.RollDownWindows(vehicle)
	return fn(vehicle)
end

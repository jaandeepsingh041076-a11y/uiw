local fn = _gn(0x3311E47B91EDCBBC)
function Global.ApplyPedBloodByZone(ped, p1, p2, p3, p4)
	return fn(ped, p1, p2, p3, _ii(p4) --[[ may be optional ]])
end

local fn = _gn(0x8A7B3952DD64D2B5)
function Global.NetworkBuyFairgroundRide(amountSpent, p1, p2, p3)
	return fn(amountSpent, p1, p2, p3)
end

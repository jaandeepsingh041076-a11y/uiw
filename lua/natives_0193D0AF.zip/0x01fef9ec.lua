local fn = _gn(0xCC9682B8951C5229)
function Global.N_0xcc9682b8951c5229(ped, r, g, b, p4)
	return fn(ped, r, g, b, p4)
end

local fn = _gn(0x8D474C8FAEFF6CDE)
function Global.IsVehicleShopResprayAllowed(vehicle)
	return fn(vehicle, _r)
end

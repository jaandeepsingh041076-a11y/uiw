local fn = _gn(0xB81656BC81FE24D1)
function Global.SetBlipFriendly(blip, toggle)
	return fn(blip, toggle)
end

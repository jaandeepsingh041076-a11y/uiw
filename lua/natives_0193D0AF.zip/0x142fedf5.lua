local fn = _gn(0x9DEF883114668116)
function Global.CreateScriptVehicleGenerator(x, y, z, heading, p4, p5, modelHash, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16)
	return fn(x, y, z, heading, p4, p5, _ch(modelHash), p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, _ri)
end

local fn = _gn(0xFE99B66D079CF6BC)
function Global.DisableControlAction(inputGroup, control, disable)
	return fn(inputGroup, control, disable)
end

local fn = _gn(0x29A16F8D621C4508)
function Global.AttachVehicleToTowTruck(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
	return fn(towTruck, vehicle, rear, hookOffsetX, hookOffsetY, hookOffsetZ)
end

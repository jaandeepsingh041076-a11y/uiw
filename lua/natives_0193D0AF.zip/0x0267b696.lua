local fn = _gn(0xEFFB25453D8600F9)
function Global.NetworkIsCableConnected()
	return fn(_r)
end

local fn = _gn(0x89D9FCC2435112F1)
function Global.TaskClimb(ped, unused)
	return fn(ped, unused)
end

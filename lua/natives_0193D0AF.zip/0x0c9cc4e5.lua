local fn = _gn(0x1A9205C1B9EE827F)
function Global.SetEntityCollision(entity, toggle, keepPhysics)
	return fn(entity, toggle, keepPhysics)
end

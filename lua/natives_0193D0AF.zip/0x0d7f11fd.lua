local fn = _gn(0xAC3A74E8384A9919)
function Global.SetWind(speed)
	return fn(speed)
end

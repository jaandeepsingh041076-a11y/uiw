local fn = _gn(0x7583B4BE4C5A41B5)
function Global.StatGetNumberOfMinutes(statName)
	return fn(_ch(statName), _ri)
end

local fn = _gn(0x59BF8C3D52C92F66)
function Global.SetVehicleCanBreak(vehicle, toggle)
	return fn(vehicle, toggle)
end

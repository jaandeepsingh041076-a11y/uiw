local fn = _gn(0x480142959D337D00)
function Global.TaskVehicleDriveWander(ped, vehicle, speed, drivingStyle)
	return fn(ped, vehicle, speed, drivingStyle)
end

local fn = _gn(0x3B6405E8AB34A907)
function Global.SetPedVisualFieldCenterAngle(ped, angle)
	return fn(ped, angle)
end

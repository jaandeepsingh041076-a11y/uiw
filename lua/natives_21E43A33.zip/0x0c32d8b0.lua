local fn = _gn(0x31B73D1EA9F01DA2)
function Global.ClearFocus()
	return fn()
end

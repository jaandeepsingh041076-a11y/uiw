local fn = _gn(0x8844BBFCE30AA9E9)
function Global.ClearPedAlternateWalkAnim(p0, p1)
	return fn(p0, p1)
end

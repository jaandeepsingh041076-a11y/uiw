local fn = _gn(0xE659E47AF827484B)
function Global.IsEntityOnScreen(entity)
	return fn(entity, _r)
end

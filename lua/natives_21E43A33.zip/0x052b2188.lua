local fn = _gn(0x4851997F37FE9B3C)
function Global.StatSetFloat(statName, value, save)
	return fn(_ch(statName), value, save, _r)
end

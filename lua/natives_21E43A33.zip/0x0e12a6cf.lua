local fn = _gn(0x67AA4D73F0CFA86B)
function Global.EnableScriptBrainSet(p0)
	return fn(p0)
end

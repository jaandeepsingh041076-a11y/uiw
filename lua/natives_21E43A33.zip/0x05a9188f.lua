local fn = _gn(0x5B9E023DC6EBEDC0)
function Global.NetworkClanDownloadMembershipPending(p0)
	return fn(_ii(p0) --[[ may be optional ]], _r)
end

local fn = _gn(0x10AB107B887214D8)
function Global.TaskVehicleShootAtPed(ped, target, p2)
	return fn(ped, target, p2)
end

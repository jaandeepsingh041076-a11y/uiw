local fn = _gn(0x01B8247A7A8B9AD1)
function Global.IsNewLoadSceneLoaded()
	return fn(_r)
end

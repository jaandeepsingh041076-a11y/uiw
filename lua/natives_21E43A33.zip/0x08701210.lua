local fn = _gn(0x7B3703D2D32DFA18)
function Global.GetEntityQuaternion(entity)
	return fn(entity, _f, _f, _f, _f)
end

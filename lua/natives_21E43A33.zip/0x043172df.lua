local fn = _gn(0xF113E3AA9BC54613)
function Global.SpecialAbilityChargeMedium(player, p1, p2)
	return fn(player, p1, p2)
end

local fn = _gn(0x2E4C123D1C8A710E)
function Global.N_0x2e4c123d1c8a710e(p0, p1, p2, p3, p4, p5, p6)
	return fn(p0, p1, p2, p3, p4, p5, p6, _ri)
end

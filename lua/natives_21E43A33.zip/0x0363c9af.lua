local fn = _gn(0x5AA3F878A178C4FC)
function Global.N_0x5aa3f878a178c4fc(p0)
	return fn(p0, _rf)
end

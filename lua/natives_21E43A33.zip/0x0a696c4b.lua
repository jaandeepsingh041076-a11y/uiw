local fn = _gn(0x4D79439A6B55AC67)
function Global.IsHelpMessageBeingDisplayed()
	return fn(_r)
end

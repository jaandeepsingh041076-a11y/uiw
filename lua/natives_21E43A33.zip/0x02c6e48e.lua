local fn = _gn(0xE902EF951DCE178F)
function Global.GetPlayerRgbColour(player)
	return fn(player, _i, _i, _i)
end

local fn = _gn(0x07C61676E5BB52CD)
function Global.N_0x07c61676e5bb52cd(p0)
	return fn(p0, _ri)
end

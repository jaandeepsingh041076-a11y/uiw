local fn = _gn(0x560A43136EB58105)
function Global.SetPedHelmet(ped, p1)
	return fn(ped, p1)
end

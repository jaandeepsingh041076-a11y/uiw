local fn = _gn(0xAE2206545888AE49)
function Global.Leaderboards2WriteData(p0)
	return fn(_ii(p0) --[[ may be optional ]], _r)
end

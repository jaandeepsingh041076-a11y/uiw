local fn = _gn(0x584b4c99)
--- Create a new light with specified type, flags, position, color, and intensity.
-- @param lightType The type of the light
-- @param flags Light flags
-- @param x X coordinate of the light position
-- @param y Y coordinate of the light position
-- @param z Z coordinate of the light position
-- @param r Red component of the light color (0-255)
-- @param g Green component of the light color (0-255)
-- @param b Blue component of the light color (0-255)
-- @param intensity Intensity of the light
function Global.PrepareLight(lightType, flags, x, y, z, r, g, b, intensity)
	return fn(lightType, flags, x, y, z, r, g, b, intensity)
end

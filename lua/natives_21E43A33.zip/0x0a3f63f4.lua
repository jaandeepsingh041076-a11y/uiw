local fn = _gn(0x3C606747B23E497B)
function Global.SetPedCombatRange(ped, p1)
	return fn(ped, p1)
end

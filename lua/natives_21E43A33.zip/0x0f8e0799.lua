local fn = _gn(0xfec3766d)
--- Creates a blank runtime texture.
-- @param txd A handle to the runtime TXD to create the runtime texture in.
-- @param txn The name for the texture in the runtime texture dictionary.
-- @param width The width of the new texture.
-- @param height The height of the new texture.
-- @return A runtime texture handle.
function Global.CreateRuntimeTexture(txd, txn, width, height)
	return fn(txd, _ts(txn), width, height, _rl)
end

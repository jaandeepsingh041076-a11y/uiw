local fn = _gn(0xF1AE5DCDBFCA2721)
function Global.N_0xf1ae5dcdbfca2721()
	return fn(_i, _i, _i, _r)
end

local fn = _gn(0xEA241BB04110F091)
function Global.SetPlayerAngry(player, IsAngry)
	return fn(player, IsAngry)
end

local fn = _gn(0x74A0FD0688F1EE45)
function Global.N_0x74a0fd0688f1ee45(p0)
	return fn(p0, _r)
end

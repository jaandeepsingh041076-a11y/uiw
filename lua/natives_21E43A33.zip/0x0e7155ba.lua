local fn = _gn(0x706D57B0F50DA710)
function Global.TriggerMusicEvent(eventName)
	return fn(_ts(eventName), _r)
end

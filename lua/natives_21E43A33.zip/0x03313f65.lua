local fn = _gn(0x55384438FC55AD8E)
function Global.N_0x55384438fc55ad8e(value)
	return fn(value)
end

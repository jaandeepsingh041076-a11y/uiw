local fn = _gn(0x65499865FCA6E5EC)
function Global.N_0x65499865fca6e5ec(doorHash)
	return fn(_ch(doorHash), _rf)
end

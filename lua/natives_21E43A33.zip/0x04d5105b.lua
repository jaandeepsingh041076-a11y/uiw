local fn = _gn(0x327EDEEEAC55C369)
function Global.IsHelpMessageFadingOut()
	return fn(_r)
end

local fn = _gn(0x052837721A854EC7)
function Global.N_0x052837721a854ec7(p0, p1, p2)
	return fn(p0, p1, p2, _ri)
end

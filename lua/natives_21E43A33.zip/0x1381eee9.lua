local fn = _gn(0x676ED266AADD31E0)
function Global.NetworkIsPartyMember(p0)
	return fn(p0, _ri)
end

local fn = _gn(0x5E6CC07646BBEAB8)
function Global.DisablePlayerFiring(player, toggle)
	return fn(player, toggle)
end

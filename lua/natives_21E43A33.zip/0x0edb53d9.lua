local fn = _gn(0xBBF327DED94E4DEB)
function Global.N_0xbbf327ded94e4deb(p0)
	return fn(_ii(p0) --[[ may be optional ]])
end

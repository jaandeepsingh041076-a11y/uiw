local fn = _gn(0xBBC08F6B4CB8FF0A)
function Global.IsCinematicCamShaking()
	return fn(_r)
end

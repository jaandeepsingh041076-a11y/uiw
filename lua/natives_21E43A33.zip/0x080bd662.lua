local fn = _gn(0xC3C221ADDDE31A11)
function Global.N_0xc3c221addde31a11(p0)
	return fn(p0)
end

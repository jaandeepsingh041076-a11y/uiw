local fn = _gn(0xF0D31AD191A74F87)
function Global.Absi(value)
	return fn(value, _ri)
end

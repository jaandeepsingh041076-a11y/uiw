local fn = _gn(0x24409FC4C55CB22D)
function Global.N_0x24409fc4c55cb22d(p0)
	return fn(p0, _ri)
end

local fn = _gn(0x8204DA7934DF3155)
function Global.N_0x8204da7934df3155(p0, p1, p2)
	return fn(p0, p1, p2)
end

local fn = _gn(0x0C0C4E81E1AC60A0)
function Global.N_0x0c0c4e81e1ac60a0()
	return fn(_ri)
end

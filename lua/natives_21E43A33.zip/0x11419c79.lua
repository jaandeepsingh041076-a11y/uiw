local fn = _gn(0x192547247864DFDD)
function Global.N_0x192547247864dfdd(vehicle, p1)
	return fn(vehicle, p1)
end

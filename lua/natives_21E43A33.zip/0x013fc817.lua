local fn = _gn(0xC593212475FAE340)
function Global.HasPedGotWeaponComponent(ped, weaponHash, componentHash)
	return fn(ped, _ch(weaponHash), _ch(componentHash), _r)
end

local fn = _gn(0x8B6817B71B85EBF0)
function Global.IsStreamingAdditionalText(additionalText)
	return fn(additionalText, _r)
end

local fn = _gn(0xE65F427EB70AB1ED)
function Global.PlaySoundFromEntity(soundId, soundName, entity, setName, p4, p5)
	return fn(soundId, _ts(soundName), entity, _ts(setName), p4, p5)
end

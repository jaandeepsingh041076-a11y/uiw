local fn = _gn(0x51669F7D1FB53D9F)
function Global.SetCinematicButtonActive(p0)
	return fn(p0)
end

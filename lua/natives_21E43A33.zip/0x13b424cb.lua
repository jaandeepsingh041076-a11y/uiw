local fn = _gn(0x6F697A66CE78674E)
function Global.N_0x6f697a66ce78674e(p0, p1)
	return fn(p0, p1)
end

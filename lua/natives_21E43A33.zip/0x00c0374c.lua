local fn = _gn(0xE547E9114277098F)
function Global.N_0xe547e9114277098f()
	return fn(_ri)
end

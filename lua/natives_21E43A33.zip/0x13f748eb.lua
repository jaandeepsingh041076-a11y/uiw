local fn = _gn(0xB13DCB4C6FAAD238)
--- Called in decompiled scripts as alternative to _SET_PED_ENEMY_AI_BLIP in an else, when the additional parameter p3 is not -1
function Global.N_0xb13dcb4c6faad238(ped, toggle, p3)
	return fn(ped, toggle, p3)
end

local fn = _gn(0x7C0A893088881D57)
function Global.HasCutsceneFinished()
	return fn(_r)
end

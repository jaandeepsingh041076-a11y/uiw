local fn = _gn(0x521FB041D93DD0E4)
function Global.SetTextGxtEntry(entry)
	return fn(_ts(entry))
end

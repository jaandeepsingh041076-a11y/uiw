local fn = _gn(0x5F7D596BAC2E7777)
function Global.OverridePopscheduleVehicleModel(scheduleId, vehicleHash)
	return fn(scheduleId, _ch(vehicleHash))
end

local fn = _gn(0x04701832B739DCE5)
function Global.TaskGoToEntityWhileAimingAtCoord(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
	return fn(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11)
end

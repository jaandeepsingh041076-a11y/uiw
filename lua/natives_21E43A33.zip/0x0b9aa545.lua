local fn = _gn(0x09693B0312F91649)
function Global.TaskRappelFromHeli(ped, p1)
	return fn(ped, p1)
end

local fn = _gn(0xC8391C309684595A)
function Global.N_0xc8391c309684595a()
	return fn()
end

local fn = _gn(0xcd420ad1)
--- An analogue to [GET_PED_PROP_INDEX](#\_0x898CC20EA75BACD8) that returns collection local prop index (inside [GET_PED_PROP_COLLECTION_NAME](#\_0x6B5653E4) collection) instead of the global prop index.
-- @param ped The target ped
-- @param anchorPoint One of the anchor points from [SET_PED_PROP_INDEX](#\_0x93376B65A266EB5F)
-- @return Local drawable index of the drawable that is currently used in the given ped and component, or -1 if the ped does not have a prop at the specified anchor point
function Global.GetPedPropCollectionLocalIndex(ped, anchorPoint)
	return fn(ped, anchorPoint, _ri)
end

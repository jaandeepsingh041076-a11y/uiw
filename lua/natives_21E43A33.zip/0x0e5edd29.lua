local fn = _gn(0xE7B80E2BF9D80BD6)
function Global.NetworkSpentHireMercenary(p0, p1, p2)
	return fn(p0, p1, p2)
end

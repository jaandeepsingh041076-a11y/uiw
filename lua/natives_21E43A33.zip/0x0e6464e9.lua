local fn = _gn(0xD2B315B6689D537D)
function Global.N_0xd2b315b6689d537d(player, p1)
	return fn(player, p1)
end

local fn = _gn(0x098AB65B9ED9A9EC)
function Global.N_0x098ab65b9ed9a9ec(p1, p2)
	return fn(_i, p1, p2, _r)
end

local fn = _gn(0x9cbfd5c1)
--- Adds new health config.
-- @param configName Name of health config. Cannot be default game health config name.
-- @param defaultHealth Default health value.
-- @param defaultArmor Default armor value.
-- @param fatiguedHealthThreshold Fatigued health threshold value.
-- @param injuredHealthThreshold Injured health threshold value.
-- @param dyingHealthThreshold Dying health threshold value.
-- @param hurtHealthThreshold Hurt health threshold value.
-- @param dogTakedownThreshold Dog takedown threshold value.
-- @param writheFromBulletThreshold Writhe from bulled threshold value.
-- @param meleeCardinalFatalAttack Melee cardinal fatal attack check value.
-- @param invincible Invincible value.
function Global.AddHealthConfig(configName, defaultHealth, defaultArmor, defaultEndurance, fatiguedHealthThreshold, injuredHealthThreshold, dyingHealthThreshold, hurtHealthThreshold, dogTakedownThreshold, writheFromBulletThreshold, meleeCardinalFatalAttack, invincible)
	return fn(_ts(configName), defaultHealth, defaultArmor, defaultEndurance, fatiguedHealthThreshold, injuredHealthThreshold, dyingHealthThreshold, hurtHealthThreshold, dogTakedownThreshold, writheFromBulletThreshold, meleeCardinalFatalAttack, invincible)
end

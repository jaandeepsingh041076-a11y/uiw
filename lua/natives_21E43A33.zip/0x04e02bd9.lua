local fn = _gn(0x4C2330E61D3DEB56)
function Global.N_0x4c2330e61d3deb56(p0)
	return fn(p0, _ri)
end

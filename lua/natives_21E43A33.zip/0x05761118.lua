local fn = _gn(0x499EF20C5DB25C59)
function Global.DoesCutsceneEntityExist(p1)
	return fn(_i, p1, _r)
end

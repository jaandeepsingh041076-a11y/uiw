local fn = _gn(0x8974647ED222EA5F)
function Global.TestProbeAgainstAllWater(p0, p1, p2, p3, p4, p5, p6, p7)
	return fn(p0, p1, p2, p3, p4, p5, p6, p7, _r)
end

local fn = _gn(0xecb8b577)
--- Toggles a train's ability to stop at stations
-- @param train The train handle
-- @param state True to make the train stop at stations. False to make the train not stop at stations
function Global.SetTrainStopAtStations(train, state)
	return fn(train, state)
end

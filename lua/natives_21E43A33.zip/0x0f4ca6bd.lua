local fn = _gn(0xCF1182F682F65307)
function Global.N_0xcf1182f682f65307(p0, p1)
	return fn(p0, p1)
end

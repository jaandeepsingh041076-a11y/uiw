local fn = _gn(0xC5286FFC176F28A2)
function Global.IsPedRunning(ped)
	return fn(ped, _r)
end

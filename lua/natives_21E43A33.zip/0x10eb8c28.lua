local fn = _gn(0x3EB1FE9E8E908E15)
function Global.TaskCower(ped, duration)
	return fn(ped, duration)
end

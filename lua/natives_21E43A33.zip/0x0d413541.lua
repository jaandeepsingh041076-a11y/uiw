local fn = _gn(0x2EABE3B06F58C1BE)
function Global.GetClosestMajorVehicleNode(x, y, z, unknown1, unknown2)
	return fn(x, y, z, _v, unknown1, unknown2, _r)
end

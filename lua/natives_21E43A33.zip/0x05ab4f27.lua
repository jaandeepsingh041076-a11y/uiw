local fn = _gn(0x330ED4D05491934F)
function Global.NetworkSessionEnter(p0, p1, p2, p3, p4, p5)
	return fn(p0, p1, p2, p3, p4, p5, _ri)
end

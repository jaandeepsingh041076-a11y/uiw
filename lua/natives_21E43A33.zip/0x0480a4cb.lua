local fn = _gn(0xF3A21BCD95725A4A)
function Global.IsControlPressed(index, control)
	return fn(index, control, _r)
end

local fn = _gn(0x1CF38D529D7441D9)
function Global.N_0x1cf38d529d7441d9(p0, p1)
	return fn(p0, p1)
end

local fn = _gn(0x4E5C93BD0C32FBF8)
function Global.ReserveNetworkMissionObjects(p0)
	return fn(p0)
end

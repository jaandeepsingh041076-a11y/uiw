local fn = _gn(0xAA5A7ECE2AA8FE70)
function Global.SetPedDesiredHeading(ped, heading)
	return fn(ped, heading)
end

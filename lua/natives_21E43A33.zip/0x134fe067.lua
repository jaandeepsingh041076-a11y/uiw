local fn = _gn(0xbce0ab63)
--- An analogue to [GET_PED_DRAWABLE_VARIATION](#\_0x67F3780DD425D4FC) that returns collection name instead of the global drawable index.
-- Should be used together with [GET_PED_DRAWABLE_VARIATION_COLLECTION_LOCAL_INDEX](#\_0x9970386F).
-- @param ped The target ped
-- @param componentId One of the components from [SET_PED_COMPONENT_VARIATION](#\_0x262B14F48D29DE80)
-- @return Collection name to which the current drawable used in the given ped and component belongs to. Returns null if Ped is not found or index is out of bounds.
function Global.GetPedDrawableVariationCollectionName(ped, componentId)
	return fn(ped, componentId, _s)
end

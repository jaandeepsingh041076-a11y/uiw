local fn = _gn(0x9304881D6F6537EA)
function Global.N_0x9304881d6f6537ea(p0)
	return fn(p0)
end

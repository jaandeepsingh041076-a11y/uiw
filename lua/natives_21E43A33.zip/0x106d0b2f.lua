local fn = _gn(0xCBF12D65F95AD686)
function Global.NetworkSetTalkerProximity(p0)
	return fn(p0)
end

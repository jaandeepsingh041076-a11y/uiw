local fn = _gn(0xD43D95C7A869447F)
function Global.TaskSeekCoverToCoverPoint(p0, p1, p2, p3, p4, p5, p6)
	return fn(p0, p1, p2, p3, p4, p5, p6)
end

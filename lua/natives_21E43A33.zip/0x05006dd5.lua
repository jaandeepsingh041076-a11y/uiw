local fn = _gn(0xBBCCE00B381F8482)
function Global.IsPedFleeing(ped)
	return fn(ped, _r)
end

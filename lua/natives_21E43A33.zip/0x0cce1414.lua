local fn = _gn(0xC843060B5765DCE7)
function Global.Asin(p0)
	return fn(p0, _rf)
end

local fn = _gn(0xA0696A65F009EE18)
function Global.ResetSpecialAbilityControlsCinematic(player, p1, p2)
	return fn(player, p1, p2)
end

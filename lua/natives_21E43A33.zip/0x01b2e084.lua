local fn = _gn(0x6B7513D9966FBEC0)
function Global.SetPedDropsWeapon(ped)
	return fn(ped)
end

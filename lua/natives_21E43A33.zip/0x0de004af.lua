local fn = _gn(0x20a1e6a2)
--- Sets default armor value for specific health config.
-- @param configName Name of health config.
-- @param newValue Value
function Global.SetHealthConfigDefaultArmor(configName, newValue)
	return fn(_ts(configName), newValue)
end

local fn = _gn(0xFA91550DF9318B22)
function Global.NetworkAcceptPresenceInvite(p0)
	return fn(p0, _r)
end

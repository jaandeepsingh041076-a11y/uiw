local fn = _gn(0x1E314167F701DC3B)
function Global.GetBlipInfoIdDisplay(blip)
	return fn(blip, _ri)
end

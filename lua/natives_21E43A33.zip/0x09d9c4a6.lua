local fn = _gn(0x6C8065A3B780185B)
function Global.SetAmbientVoiceName(ped, name)
	return fn(ped, _ts(name))
end

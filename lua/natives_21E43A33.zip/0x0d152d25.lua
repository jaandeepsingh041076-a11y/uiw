local fn = _gn(0x20510814175EA477)
function Global.ResetPedStrafeClipset(ped)
	return fn(ped)
end

local fn = _gn(0xB51B9AB9EF81868C)
function Global.N_0xb51b9ab9ef81868c(p0)
	return fn(p0)
end

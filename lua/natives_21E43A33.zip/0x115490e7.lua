local fn = _gn(0x9AA46BADAD0E27ED)
function Global.N_0x9aa46badad0e27ed()
	return fn(_ri)
end

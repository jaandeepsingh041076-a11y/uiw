local fn = _gn(0x77A5B103C87F476E)
function Global.SetPedPathCanUseLadders(ped, Toggle)
	return fn(ped, Toggle, _ri)
end

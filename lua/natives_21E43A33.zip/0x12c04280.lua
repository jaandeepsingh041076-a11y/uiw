local fn = _gn(0xf71542f7)
--- Gets a ped model's health config.
-- @param modelHash Ped's model.
function Global.GetPedModelHealthConfig(modelHash)
	return fn(_ch(modelHash), _ri)
end

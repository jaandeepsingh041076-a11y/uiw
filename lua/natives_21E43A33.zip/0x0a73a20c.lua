local fn = _gn(0x56CE820830EF040B)
function Global.N_0x56ce820830ef040b(p0)
	return fn(p0, _ri)
end

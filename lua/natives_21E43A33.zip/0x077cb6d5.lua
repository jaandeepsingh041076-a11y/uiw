local fn = _gn(0xC17AD0E5752BECDA)
function Global.N_0xc17ad0e5752becda(componentHash)
	return fn(_ch(componentHash), _ri)
end

local fn = _gn(0xE37F721824571784)
function Global.ApplyImpulseToCloth(posX, posY, posZ, vecX, vecY, vecZ, impulse)
	return fn(posX, posY, posZ, vecX, vecY, vecZ, impulse)
end

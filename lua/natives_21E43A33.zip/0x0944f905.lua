local fn = _gn(0xF8C397922FC03F41)
function Global.GetConvertibleRoofState(vehicle)
	return fn(vehicle, _ri)
end

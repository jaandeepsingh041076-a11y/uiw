local fn = _gn(0xB2C086CC1BF8F2BF)
function Global.IsPedDoingDriveby(ped)
	return fn(ped, _r)
end

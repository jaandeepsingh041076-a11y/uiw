local fn = _gn(0xF6F4383B7C92F11A)
function Global.N_0xf6f4383b7c92f11a(p0)
	return fn(p0)
end

local fn = _gn(0x6551B1F7F6CD46EA)
function Global.N_0x6551b1f7f6cd46ea(p0)
	return fn(p0)
end

local fn = _gn(0xF166E48407BAC484)
function Global.TaskCombatPed(ped, targetPed, p2, p3)
	return fn(ped, targetPed, p2, p3)
end

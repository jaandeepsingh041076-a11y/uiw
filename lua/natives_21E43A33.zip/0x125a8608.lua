local fn = _gn(0x5B50ABB1FE3746F4)
function Global.N_0x5b50abb1fe3746f4()
	return fn(_ri)
end

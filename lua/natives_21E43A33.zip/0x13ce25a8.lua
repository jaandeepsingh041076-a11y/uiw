local fn = _gn(0x9E8C908F41584ECD)
function Global.SetPedMoveAnimsBlendOut(ped)
	return fn(ped)
end

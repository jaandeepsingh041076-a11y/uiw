local fn = _gn(0x5FBCA48327B914DF)
function Global.N_0x5fbca48327b914df(p0, p1)
	return fn(p0, p1)
end

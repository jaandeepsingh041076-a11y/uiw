local fn = _gn(0xD0EE05FE193646EA)
function Global.N_0xd0ee05fe193646ea()
	return fn(_i, _i, _i, _r)
end

local fn = _gn(0x52923C4710DD9907)
function Global.ForceRoomForEntity(entity, interiorID, p0)
	return fn(entity, interiorID, p0)
end

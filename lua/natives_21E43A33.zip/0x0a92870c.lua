local fn = _gn(0xA29177F7703B5644)
function Global.N_0xa29177f7703b5644()
	return fn()
end

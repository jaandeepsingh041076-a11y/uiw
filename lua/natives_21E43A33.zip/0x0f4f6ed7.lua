local fn = _gn(0xAC6D445B994DF95E)
function Global.RemovePedElegantly(ped)
	return fn(_ii(ped) --[[ may be optional ]])
end

local fn = _gn(0x593850C16A36B692)
function Global.ShutdownAndLaunchSinglePlayerGame()
	return fn()
end

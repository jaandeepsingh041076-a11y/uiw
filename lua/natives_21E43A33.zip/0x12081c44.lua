local fn = _gn(0xDFD5033FDBA0A9C8)
function Global.HasEntityBeenDamagedByAnyVehicle(entity)
	return fn(entity, _r)
end

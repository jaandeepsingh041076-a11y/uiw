local fn = _gn(0xD705740BB0A1CF4C)
function Global.HasPlayerBeenSpottedInStolenVehicle(player)
	return fn(player, _r)
end

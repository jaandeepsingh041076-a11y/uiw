local fn = _gn(0xb2d37e97)
--- Set additional configuration flags for an existing light
-- @param extraFlags Bitmask of extra flags
function Global.SetLightExtraflags(extraFlags)
	return fn(extraFlags)
end

local fn = _gn(0xD830567D88A1E873)
function Global.NetworkSetEntityCanBlend(p0, toggle)
	return fn(p0, toggle)
end

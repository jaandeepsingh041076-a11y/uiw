local fn = _gn(0x71B0892EC081D60A)
function Global.SetVehicleExplodesOnHighExplosionDamage(vehicle, toggle)
	return fn(vehicle, toggle)
end

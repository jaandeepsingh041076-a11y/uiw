local fn = _gn(0xAC83B1DB38D0ADA0)
function Global.TaskHeliChase(pilot, entityToFollow, x, y, z)
	return fn(pilot, entityToFollow, x, y, z)
end

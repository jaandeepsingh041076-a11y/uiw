local fn = _gn(0xBB0527EC6341496D)
function Global.N_0xbb0527ec6341496d()
	return fn(_ri)
end

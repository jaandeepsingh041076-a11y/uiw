local fn = _gn(0x45A83257ED02D9BC)
function Global.N_0x45a83257ed02d9bc()
	return fn()
end

local fn = _gn(0xE679E3E06E363892)
function Global.NetworkOverrideClockTime(Hours, Minutes, Seconds)
	return fn(Hours, Minutes, Seconds)
end

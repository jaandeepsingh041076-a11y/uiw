local fn = _gn(0x62522002E0C391BA)
function Global.IsSynchronizedSceneLooped(p0)
	return fn(p0, _r)
end

local fn = _gn(0x7DCF7C708D292D55)
function Global.OverrideCamSplineMotionBlur(p0, p1, p2, p3)
	return fn(p0, p1, p2, p3)
end

local fn = _gn(0x8E02D73914064223)
function Global.NetworkAddFriend()
	return fn(_i, _i, _r)
end

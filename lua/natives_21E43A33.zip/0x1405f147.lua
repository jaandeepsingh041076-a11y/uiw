local fn = _gn(0xCEDABC5900A0BF97)
function Global.IsPedJumping(ped)
	return fn(ped, _r)
end

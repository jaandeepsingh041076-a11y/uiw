local fn = _gn(0x758A5C1B3B1E1990)
function Global.N_0x758a5c1b3b1e1990(p0)
	return fn(p0)
end

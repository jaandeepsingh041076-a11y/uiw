local fn = _gn(0x896a0c11)
--- Gets the specified tracks node count.
-- @param trackIndex The track index
-- @return The amount of track nodes on the specified track
function Global.GetTrackNodeCount(trackIndex)
	return fn(trackIndex, _ri)
end

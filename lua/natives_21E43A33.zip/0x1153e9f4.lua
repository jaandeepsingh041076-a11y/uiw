local fn = _gn(0x5B6010B3CBC29095)
function Global.N_0x5b6010b3cbc29095(p0, p1)
	return fn(p0, p1)
end

local fn = _gn(0xF2BFA0430F0A0FCB)
function Global.SetVehicleDoorControl(vehicle, doorIndex, p2, p3)
	return fn(vehicle, doorIndex, p2, p3)
end

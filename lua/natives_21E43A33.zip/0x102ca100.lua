local fn = _gn(0x815E5E3073DA1D67)
function Global.SetBalanceAddMachine()
	return fn(_i, _i, _r)
end

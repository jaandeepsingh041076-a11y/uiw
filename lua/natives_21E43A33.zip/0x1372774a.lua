local fn = _gn(0xE058175F8EAFE79A)
function Global.N_0xe058175f8eafe79a(p0)
	return fn(p0)
end

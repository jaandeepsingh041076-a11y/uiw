local fn = _gn(0x9A62EC95AE10E011)
function Global.N_0x9a62ec95ae10e011()
	return fn(_ri)
end

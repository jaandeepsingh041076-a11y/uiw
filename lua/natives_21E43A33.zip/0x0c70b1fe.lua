local fn = _gn(0x1C7302E725259789)
function Global.DoesTextBlockExist(gxt)
	return fn(_ts(gxt), _r)
end

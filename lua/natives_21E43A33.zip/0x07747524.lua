local fn = _gn(0x9489659372A81585)
function Global.N_0x9489659372a81585()
	return fn(_ri)
end

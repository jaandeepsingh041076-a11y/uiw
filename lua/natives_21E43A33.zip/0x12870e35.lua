local fn = _gn(0xB50EB4CCB29704AC)
function Global.N_0xb50eb4ccb29704ac(p0)
	return fn(p0)
end

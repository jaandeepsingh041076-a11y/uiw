local fn = _gn(0x8EEDA153AD141BA4)
function Global.SetEveryoneIgnorePlayer(player, toggle)
	return fn(player, toggle)
end

local fn = _gn(0x152D90E4C1B4738A)
function Global.N_0x152d90e4c1b4738a()
	return fn(_i, _i, _r)
end

local fn = _gn(0xB2CBCD0930DFB420)
function Global.CanSetExitStateForCamera(p0)
	return fn(p0, _r)
end

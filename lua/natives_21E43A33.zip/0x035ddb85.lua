local fn = _gn(0x6ACF6B7225801CD7)
function Global.SetSynchronizedSceneOrigin(p0, p1, p2, p3, p4, p5, p6, p7)
	return fn(p0, p1, p2, p3, p4, p5, p6, p7)
end

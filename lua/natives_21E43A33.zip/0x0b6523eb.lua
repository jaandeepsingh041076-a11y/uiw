local fn = _gn(0xCD67AD041A394C9C)
function Global.N_0xcd67ad041a394c9c(p0)
	return fn(p0, _ri)
end

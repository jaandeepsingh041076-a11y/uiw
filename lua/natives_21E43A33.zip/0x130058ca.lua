local fn = _gn(0xA6294919E56FF02A)
function Global.DisplayHud(Toggle)
	return fn(Toggle, _ri)
end

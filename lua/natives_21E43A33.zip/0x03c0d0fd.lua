local fn = _gn(0x7CAEC29ECB5DFEBB)
function Global.RegisterFloatToSave(name)
	return fn(_i, _ts(name))
end

local fn = _gn(0x22EF8FF8778030EB)
function Global.ResetPedInVehicleContext(p0)
	return fn(p0)
end

local fn = _gn(0x0EDEC3C276198689)
function Global.PedToNet(ped)
	return fn(ped, _ri)
end

local fn = _gn(0x2170813D3DD8661B)
function Global.GetTvVolume()
	return fn(_rf)
end

local fn = _gn(0x9B0F3DCA3DB0F4CD)
function Global.GetVehicleLandingGear(vehicle)
	return fn(vehicle, _ri)
end

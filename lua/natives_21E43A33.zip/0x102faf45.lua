local fn = _gn(0x936E6168A9BCEDB5)
function Global.GetEventExists(p0, eventIndex)
	return fn(p0, eventIndex, _r)
end

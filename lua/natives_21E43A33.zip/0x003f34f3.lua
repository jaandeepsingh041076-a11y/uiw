local fn = _gn(0x43A66C31C68491C0)
function Global.GetPlayerPed(player)
	return fn(player, _ri)
end

local fn = _gn(0xA3C0B359DCB848B6)
function Global.ShowNumberOnBlip(blip, number)
	return fn(blip, number)
end

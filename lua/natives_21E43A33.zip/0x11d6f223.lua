local fn = _gn(0xA097AB275061FB21)
function Global.N_0xa097ab275061fb21()
	return fn(_ri)
end

local fn = _gn(0xBF371CD2B64212FD)
function Global.N_0xbf371cd2b64212fd(p0)
	return fn(p0)
end

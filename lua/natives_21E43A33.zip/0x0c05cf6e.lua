local fn = _gn(0x5CEC1A84620E7D5B)
function Global.SetDisableBreaking(rope, enabled)
	return fn(rope, enabled, _ri)
end

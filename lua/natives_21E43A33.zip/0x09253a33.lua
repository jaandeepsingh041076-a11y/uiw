local fn = _gn(0x4EC12697209F2196)
function Global.IsPlayerRidingTrain(player)
	return fn(player, _r)
end

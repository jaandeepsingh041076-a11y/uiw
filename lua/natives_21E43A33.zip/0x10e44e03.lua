local fn = _gn(0xE38CB9D7D39FDBCC)
function Global.N_0xe38cb9d7d39fdbcc(p0, p1, p2, p3)
	return fn(p0, p1, p2, p3)
end

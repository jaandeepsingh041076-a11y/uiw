local fn = _gn(0xCD536C4D33DCC900)
function Global.PlayEndCreditsMusic(p0)
	return fn(p0)
end

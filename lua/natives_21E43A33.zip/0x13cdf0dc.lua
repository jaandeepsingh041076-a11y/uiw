local fn = _gn(0x69FE6DC87BD2A5E9)
function Global.N_0x69fe6dc87bd2a5e9(p0)
	return fn(p0)
end

local fn = _gn(0xBD2A8EC3AF4DE7DB)
function Global.TaskUseMobilePhone(ped, p1)
	return fn(ped, p1)
end

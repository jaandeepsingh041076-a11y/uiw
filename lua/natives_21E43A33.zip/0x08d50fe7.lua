local fn = _gn(0x606E4D3E3CCCF3EB)
function Global.N_0x606e4d3e3cccf3eb()
	return fn(_ri)
end

local fn = _gn(0x30CF4BDA4FCB1905)
function Global.GetIsWidescreen()
	return fn(_r)
end

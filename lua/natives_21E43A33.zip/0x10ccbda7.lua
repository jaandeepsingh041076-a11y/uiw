local fn = _gn(0x05983472F0494E60)
function Global.CreateIncidentWithEntity(p0, p1, p2, p3, p4)
	return fn(p0, p1, p2, p3, _ii(p4) --[[ may be optional ]], _r)
end

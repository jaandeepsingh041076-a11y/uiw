local fn = _gn(0x1DB21A44B09E8BA3)
function Global.SetTextChatUnk(p0)
	return fn(p0)
end

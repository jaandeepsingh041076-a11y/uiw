local fn = _gn(0x814C9D19DFD69679)
function Global.GetMaxRangeOfCurrentPedWeapon(ped)
	return fn(ped, _rf)
end

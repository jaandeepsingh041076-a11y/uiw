local fn = _gn(0xE6B7B0ACD4E4B75E)
function Global.CancelStuntJump()
	return fn()
end

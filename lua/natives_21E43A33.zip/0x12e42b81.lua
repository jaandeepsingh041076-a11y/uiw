local fn = _gn(0x3195F8DD0D531052)
function Global.N_0x3195f8dd0d531052(p0, p1)
	return fn(p0, p1, _i, _i, _r)
end

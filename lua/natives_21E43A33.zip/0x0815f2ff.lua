local fn = _gn(0x983765856F2564F9)
function Global.SetVehicleEngineCanDegrade(vehicle, toggle)
	return fn(vehicle, toggle)
end

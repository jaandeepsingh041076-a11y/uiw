local fn = _gn(0x9614B71F8ADB982B)
function Global.N_0x9614b71f8adb982b()
	return fn(_ri)
end

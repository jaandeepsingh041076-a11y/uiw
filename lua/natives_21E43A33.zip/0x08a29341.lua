local fn = _gn(0x9CD43EEE12BF4DD0)
function Global.AddEntityIcon(entity, icon)
	return fn(entity, _ts(icon), _ri)
end

local fn = _gn(0x5486A79D9FBD342D)
function Global.GetJackTarget(p0)
	return fn(p0, _ri)
end

local fn = _gn(0xfbc64da3)
--- This completely disables rendering of fog volumes (vfxfogvolumeinfo.ymt).
-- @param state Toggle on or off.
function Global.SetFogVolumeRenderDisabled(state)
	return fn(state)
end

local fn = _gn(0xFCFACD0DB9D7A57D)
function Global.N_0xfcfacd0db9d7a57d(ped, p1)
	return fn(ped, p1)
end

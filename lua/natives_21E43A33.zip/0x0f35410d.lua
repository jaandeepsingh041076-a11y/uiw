local fn = _gn(0x621C6E4729388E41)
function Global.N_0x621c6e4729388e41(p0)
	return fn(p0, _r)
end

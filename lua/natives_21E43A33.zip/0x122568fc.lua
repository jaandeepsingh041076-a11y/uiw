local fn = _gn(0xD62A67D26D9653E6)
function Global.RequestStreamedScript(scriptHash)
	return fn(_ch(scriptHash))
end

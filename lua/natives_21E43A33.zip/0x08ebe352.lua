local fn = _gn(0xE5608CA7BC163A5F)
function Global.N_0xe5608ca7bc163a5f(p0, p1, p2)
	return fn(_ts(p0), _ts(p1), _ii(p2) --[[ may be optional ]], _r)
end

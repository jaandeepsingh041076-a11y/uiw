local fn = _gn(0x3B390A939AF0B5FC)
function Global.GetCurrentPedWeaponEntityIndex(ped)
	return fn(ped, _ri)
end

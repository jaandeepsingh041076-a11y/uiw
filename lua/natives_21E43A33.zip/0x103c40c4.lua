local fn = _gn(0x5E203DA2BA15D436)
function Global.N_0x5e203da2ba15d436(p0)
	return fn(p0, _ri)
end

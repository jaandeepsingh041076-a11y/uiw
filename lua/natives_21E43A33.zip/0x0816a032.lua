local fn = _gn(0x06FAACD625D80CAA)
function Global.N_0x06faacd625d80caa(p0)
	return fn(p0)
end

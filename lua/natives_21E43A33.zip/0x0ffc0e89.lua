local fn = _gn(0x46A1E1A299EC4BBA)
function Global.RemoveVehiclesFromGeneratorsInArea(x1, y1, z1, x2, y2, z2)
	return fn(x1, y1, z1, x2, y2, z2)
end

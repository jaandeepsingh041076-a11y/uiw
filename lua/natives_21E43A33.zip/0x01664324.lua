local fn = _gn(0x1EAF30FCFBF5AF74)
function Global.IsVehicleNodeIdValid(vehicleNodeId)
	return fn(vehicleNodeId, _r)
end

local fn = _gn(0xD9F8455409B525E9)
function Global.AddShockingEventAtPosition(type, x, y, z, duration)
	return fn(type, x, y, z, duration, _ri)
end

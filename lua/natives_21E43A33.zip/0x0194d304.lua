local fn = _gn(0xFE99B66D079CF6BC)
function Global.DisableControlAction(index, control, disable)
	return fn(index, control, disable)
end

local fn = _gn(0xBB03C38DD3FB7FFD)
function Global.SetPedAsCop(ped, toggle)
	return fn(ped, toggle)
end

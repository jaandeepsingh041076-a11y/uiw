local fn = _gn(0x02C40BF885C567B6)
function Global.N_0x02c40bf885c567b6(p0)
	return fn(p0, _ri)
end

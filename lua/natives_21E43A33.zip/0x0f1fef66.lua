local fn = _gn(0xc74da47c)
--- GET_INTERIOR_PORTAL_FLAG
-- @param interiorId The target interior.
-- @param portalIndex Interior portal index.
-- @return Portal's flag.
function Global.GetInteriorPortalFlag(interiorId, portalIndex)
	return fn(interiorId, portalIndex, _ri)
end

local fn = _gn(0xB32209EFFDC04913)
function Global.ClearAllBrokenGlass()
	return fn(_ri)
end

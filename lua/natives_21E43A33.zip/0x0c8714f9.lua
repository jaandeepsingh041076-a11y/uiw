local fn = _gn(0xC61B86C9F61EB404)
function Global.N_0xc61b86c9f61eb404(p0)
	return fn(p0)
end

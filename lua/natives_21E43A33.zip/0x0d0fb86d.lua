local fn = _gn(0x9E5B5E4D2CCD2259)
function Global.SmashVehicleWindow(vehicle, index)
	return fn(vehicle, index, _ri)
end

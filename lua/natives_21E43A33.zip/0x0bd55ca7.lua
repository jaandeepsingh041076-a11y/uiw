local fn = _gn(0xC79196DCB36F6121)
function Global.N_0xc79196dcb36f6121(p0)
	return fn(p0)
end

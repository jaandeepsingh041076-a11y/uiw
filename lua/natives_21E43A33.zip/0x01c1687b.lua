local fn = _gn(0x89D9FCC2435112F1)
function Global.TaskClimb(p0, p1)
	return fn(p0, p1)
end

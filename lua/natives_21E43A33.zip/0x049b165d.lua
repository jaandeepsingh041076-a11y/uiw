local fn = _gn(0x6671F3EEC681BDA1)
function Global.TaskAimGunAtCoord(ped, x, y, z, time, p5, p6)
	return fn(ped, x, y, z, time, p5, p6)
end

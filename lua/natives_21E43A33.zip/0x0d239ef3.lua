local fn = _gn(0x313CE5879CEB6FCD)
function Global.GetRandomFloatInRange(startRange, endRange)
	return fn(startRange, endRange, _rf)
end

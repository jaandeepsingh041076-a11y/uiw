local fn = _gn(0xC54C95DA968EC5B5)
function Global.SetPlayerSimulateAiming(player, toggle)
	return fn(player, toggle)
end

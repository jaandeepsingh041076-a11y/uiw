local fn = _gn(0xD8C3BE3EE94CAF2D)
function Global.N_0xd8c3be3ee94caf2d(p0, p1, p2, p3, p4)
	return fn(p0, p1, p2, p3, p4)
end

local fn = _gn(0x195AEEB13CEFE2EE)
function Global.TaskVehicleGotoNavmesh(ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
	return fn(ped, vehicle, x, y, z, speed, behaviorFlag, stoppingRange)
end

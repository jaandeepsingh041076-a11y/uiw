local fn = _gn(0xC6DC823253FBB366)
function Global.N_0xc6dc823253fbb366()
	return fn(_ri)
end

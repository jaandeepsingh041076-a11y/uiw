local fn = _gn(0xEDF7F927136C224B)
function Global.N_0xedf7f927136c224b()
	return fn(_ri)
end

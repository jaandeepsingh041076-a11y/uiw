local fn = _gn(0x5AFEEDD9BB2899D7)
function Global.SetVehicleProvidesCover(vehicle, toggle)
	return fn(vehicle, toggle)
end

local fn = _gn(0x84ED31191CC5D2C9)
function Global.GetIsHidef()
	return fn(_r)
end

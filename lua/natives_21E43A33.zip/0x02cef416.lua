local fn = _gn(0x6ADAABD3068C5235)
function Global.N_0x6adaabd3068c5235()
	return fn(_ri)
end

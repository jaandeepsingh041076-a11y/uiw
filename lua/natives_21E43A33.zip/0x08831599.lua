local fn = _gn(0x873C9F3104101DD3)
function Global.GetScreenActiveResolution()
	return fn(_i, _i)
end

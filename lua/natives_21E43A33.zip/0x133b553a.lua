local fn = _gn(0xDF2E1F7742402E81)
function Global.AnimateGameplayCamZoom(p0, _distance)
	return fn(p0, _distance)
end

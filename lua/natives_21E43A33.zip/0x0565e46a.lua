local fn = _gn(0xF7F203E31F96F6A1)
function Global.N_0xf7f203e31f96f6a1(vehicle, flag)
	return fn(vehicle, flag, _r)
end

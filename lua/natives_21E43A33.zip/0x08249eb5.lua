local fn = _gn(0x27F9D613092159CF)
function Global.RemoveAllPickupsOfType(p0)
	return fn(p0)
end

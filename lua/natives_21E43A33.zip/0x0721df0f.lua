local fn = _gn(0xCAA15F13EBD417FF)
function Global.SetNumberOfParkedVehicles(value)
	return fn(value, _ri)
end

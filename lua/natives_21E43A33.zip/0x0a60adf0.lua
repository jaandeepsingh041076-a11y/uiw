local fn = _gn(0xB7A628320EFF8E47)
function Global.Vdist2(x1, y1, z1, x2, y2, z2)
	return fn(x1, y1, z1, x2, y2, z2, _rf)
end

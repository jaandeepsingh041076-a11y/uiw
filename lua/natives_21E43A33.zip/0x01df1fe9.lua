local fn = _gn(0xAFEBB0D5D8F687D2)
function Global.NetworkGetMaxFriends()
	return fn(_ri)
end

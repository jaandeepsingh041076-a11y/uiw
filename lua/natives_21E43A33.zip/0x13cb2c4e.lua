local fn = _gn(0x608207E7A8FB787C)
function Global.SetAllLowPriorityVehicleGeneratorsActive(active)
	return fn(active)
end

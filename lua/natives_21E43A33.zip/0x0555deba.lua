local fn = _gn(0x26AA915AD89BFB4B)
function Global.IsEntityAttachedToAnyVehicle(entity)
	return fn(entity, _r)
end

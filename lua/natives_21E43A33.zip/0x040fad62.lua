local fn = _gn(0xD3A6A0EF48823A8C)
function Global.N_0xd3a6a0ef48823a8c()
	return fn(_ri)
end

local fn = _gn(0x8378627201D5497D)
function Global.SetPedChanceOfFiringBlanks(weaponHash, xBias, yBias)
	return fn(_ch(weaponHash), xBias, yBias)
end

local fn = _gn(0x6C38AF3693A69A91)
function Global.SetPtfxAssetNextCall(name)
	return fn(_ts(name))
end

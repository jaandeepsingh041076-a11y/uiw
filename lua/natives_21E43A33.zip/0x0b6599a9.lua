local fn = _gn(0x442E0A7EDE4A738A)
function Global.GetThisScriptName()
	return fn(_s)
end
